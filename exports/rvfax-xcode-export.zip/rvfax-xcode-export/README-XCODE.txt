RVFAX Pro — Xcode / Capacitor export
====================================

Capacitor hybrid app (React web + iOS shell).

QUICK START (Mac)
1. Unzip
2. npm install
3. export CAP_SERVER_URL="https://YOUR-LIVE-APP.vercel.app"
4. npx cap sync ios
5. open ios/App/App.xcodeproj   OR: npx cap open ios
6. Xcode → Signing → your Team → Run / Archive → TestFlight

See UPDATE-XCODE.md and CAPACITOR.md inside this folder.
node_modules is not included — always npm install after unzip.
