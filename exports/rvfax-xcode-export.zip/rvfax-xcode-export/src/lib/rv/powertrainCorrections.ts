/**
 * Hard brochure corrections for known catalog / Live Grok mistakes.
 * These ALWAYS win over static rvData defaults AND over Live Grok powertrain
 * fields (engine / HP / torque / chassis / transmission). Expand as we verify.
 */

export type PowertrainCorrection = {
  /** Match year range inclusive */
  yearMin: number;
  yearEnd: number;
  makeIncludes: string;
  modelIncludes: string;
  /** Optional floorplan substring */
  floorplanIncludes?: string;
  engine: string;
  horsepower: number;
  torqueLbFt?: number;
  chassis?: string;
  transmission?: string;
  fuelType?: "Diesel" | "Gas" | "Propane";
  note?: string;
};

/**
 * Verified / brochure-backed patches. Prefer official MY brochures.
 * Display + cache layers pin these over Live Grok so sibling-model steals
 * (e.g. Allegro Bus ISL on a RED, gas F53 Allegro Open Road on a RED) never stick.
 */
export const POWERTRAIN_CORRECTIONS: PowertrainCorrection[] = [
  {
    yearMin: 2020,
    yearEnd: 2026,
    makeIncludes: "thor",
    modelIncludes: "vegas",
    engine: "Ford 7.3L V8 (Godzilla) 325HP",
    horsepower: 325,
    torqueLbFt: 450,
    chassis: "Ford E-Series cutaway (Class A body)",
    transmission: "TorqShift automatic",
    fuelType: "Gas",
    note: "Vegas compact RUV — cutaway chassis NOT F53; Thor OEM 325/450, 55 gal, hitch 8k",
  },
  {
    yearMin: 2020,
    yearEnd: 2026,
    makeIncludes: "thor",
    modelIncludes: "axis",
    engine: "Ford 7.3L V8 (Godzilla) 325HP",
    horsepower: 325,
    torqueLbFt: 450,
    chassis: "Ford E-Series cutaway (Class A body)",
    transmission: "TorqShift automatic",
    fuelType: "Gas",
    note: "Axis sister to Vegas — same cutaway 7.3L package, not F53 ACE/Windsport",
  },
  {
    yearMin: 2014,
    yearEnd: 2019,
    makeIncludes: "thor",
    modelIncludes: "vegas",
    engine: "Ford Triton V10 6.8L",
    horsepower: 305,
    torqueLbFt: 420,
    chassis: "Ford E-350 / E-450 cutaway",
    fuelType: "Gas",
    note: "Early Vegas V10 cutaway",
  },
  {
    yearMin: 2014,
    yearEnd: 2019,
    makeIncludes: "thor",
    modelIncludes: "axis",
    engine: "Ford Triton V10 6.8L",
    horsepower: 305,
    torqueLbFt: 420,
    chassis: "Ford E-350 / E-450 cutaway",
    fuelType: "Gas",
    note: "Early Axis V10 cutaway",
  },

  // Fleetwood Discovery (regular, not LXE) — Cummins ISB / B6.7 class, not 8.9 ISL
  {
    yearMin: 2018,
    yearEnd: 2024,
    makeIncludes: "fleetwood",
    modelIncludes: "discovery",
    engine: "Cummins B6.7 (ISB)",
    horsepower: 360,
    torqueLbFt: 800,
    chassis: "Freightliner XC-Series",
    transmission: "Allison 3000 MH",
    fuelType: "Diesel",
    note: "Regular Discovery — not LXE / not ISL 8.9",
  },
  {
    yearMin: 2018,
    yearEnd: 2024,
    makeIncludes: "fleetwood",
    modelIncludes: "discovery lxe",
    engine: "Cummins L9",
    horsepower: 450,
    torqueLbFt: 1250,
    chassis: "Freightliner / Spartan (by option)",
    fuelType: "Diesel",
    note: "Discovery LXE high-line",
  },
  // Entegra Reatta — mid diesel B6.7, not Aspire/Anthem L9
  {
    yearMin: 2018,
    yearEnd: 2026,
    makeIncludes: "entegra",
    modelIncludes: "reatta",
    engine: "Cummins B6.7 turbo diesel",
    horsepower: 360,
    torqueLbFt: 800,
    chassis: "Spartan K1 raised-rail",
    transmission: "Allison 3000 MH",
    fuelType: "Diesel",
    note: "Reatta diesel — not Aspire/Anthem L9",
  },
  // Entegra Vision — gas F53 Godzilla only
  {
    yearMin: 2019,
    yearEnd: 2026,
    makeIncludes: "entegra",
    modelIncludes: "vision",
    engine: "Ford 7.3L V8 Godzilla",
    horsepower: 350,
    torqueLbFt: 468,
    chassis: "Ford F-53",
    transmission: "TorqShift 6-speed automatic",
    fuelType: "Gas",
    note: "Vision gas F-53 only — never diesel",
  },
  {
    yearMin: 2020,
    yearEnd: 2026,
    makeIncludes: "newmar",
    modelIncludes: "bay star",
    engine: "Ford 7.3L V8 Godzilla",
    horsepower: 350,
    torqueLbFt: 468,
    chassis: "Ford F53",
    transmission: "TorqShift 6-speed automatic",
    fuelType: "Gas",
    note: "Bay Star gas F-53 Godzilla — never diesel L9 450; not Kountry Star",
  },
  // Forest River FR3 — gas F53 only (OEM brochure 335 HP / 468 lb-ft Godzilla)
  {
    yearMin: 2020,
    yearEnd: 2026,
    makeIncludes: "forest river",
    modelIncludes: "fr3",
    engine: "Ford 7.3L V8 Godzilla",
    horsepower: 335,
    torqueLbFt: 468,
    chassis: "Ford F53",
    transmission: "TorqShift 6-speed automatic",
    fuelType: "Gas",
    note: "FR3 gas Class A — Ford 7.3 Godzilla 335/468 on F53; not diesel",
  },
  {
    yearMin: 2015,
    yearEnd: 2019,
    makeIncludes: "forest river",
    modelIncludes: "fr3",
    engine: "Ford Triton V10 6.8L",
    horsepower: 320,
    chassis: "Ford F53",
    transmission: "TorqShift automatic",
    fuelType: "Gas",
    note: "FR3 pre-Godzilla Triton V10 era",
  },
  // Newmar Kountry Star — diesel pusher (NOT gas F53 / Godzilla; NOT Dutch Star L9 450)
  {
    yearMin: 2020,
    yearEnd: 2026,
    makeIncludes: "newmar",
    modelIncludes: "kountry star",
    engine: "Cummins B6.7 360HP",
    horsepower: 360,
    torqueLbFt: 800,
    chassis: "Freightliner XCR",
    transmission: "Allison 3000 MH",
    fuelType: "Diesel",
    note: "Kountry Star diesel pusher — Cummins B6.7 360/800 on Freightliner XCR (OEM). Not Bay Star 7.3 gas, not Dutch Star L9 450",
  },
  {
    yearMin: 2012,
    yearEnd: 2019,
    makeIncludes: "newmar",
    modelIncludes: "kountry star",
    engine: "Cummins ISB / B6.7 diesel",
    horsepower: 340,
    torqueLbFt: 700,
    chassis: "Freightliner XC / XCR",
    transmission: "Allison 3000 MH",
    fuelType: "Diesel",
    note: "Kountry Star mid-diesel — not Ford F53 gas, not L9 450",
  },
  // Thor Palazzo / Hurricane mid bands (common mixups)
  {
    yearMin: 2018,
    yearEnd: 2026,
    makeIncludes: "thor",
    modelIncludes: "palazzo",
    engine: "Cummins B6.7 (ISB) 340HP",
    horsepower: 340,
    torqueLbFt: 700,
    chassis: "Freightliner XC-S",
    transmission: "Allison 2100 / 2500 MH",
    fuelType: "Diesel",
    note: "Palazzo mid-diesel — not ISL 8.9",
  },
  {
    yearMin: 2016,
    yearEnd: 2026,
    makeIncludes: "winnebago",
    modelIncludes: "forza",
    engine: "Cummins B6.7 (ISB) 340HP",
    horsepower: 340,
    torqueLbFt: 700,
    chassis: "Freightliner XC",
    fuelType: "Diesel",
    note: "Forza mid-diesel — not ISL 8.9",
  },
  {
    yearMin: 2016,
    yearEnd: 2026,
    makeIncludes: "winnebago",
    modelIncludes: "journey",
    engine: "Cummins B6.7 / ISB 340HP",
    horsepower: 340,
    torqueLbFt: 700,
    chassis: "Freightliner XC",
    fuelType: "Diesel",
    note: "Journey diesel — B6.7 class not ISL",
  },
  {
    yearMin: 2016,
    yearEnd: 2026,
    makeIncludes: "winnebago",
    modelIncludes: "adventurer",
    engine: "Ford 6.8L V10 / 7.3L Godzilla (by year)",
    horsepower: 320,
    chassis: "Ford F53",
    fuelType: "Gas",
    note: "Post-V10 F53 gas Class A",
  },
  // Tiffin Allegro RED (legacy nameplate) — diesel mid-coach, NEVER Ford V10 and NEVER ISL 8.9 bus class
  {
    yearMin: 2010,
    yearEnd: 2013,
    makeIncludes: "tiffin",
    modelIncludes: "allegro red",
    engine: "Cummins ISB 6.7L 340HP",
    horsepower: 340,
    torqueLbFt: 700,
    chassis: "Freightliner XC raised-rail",
    transmission: "Allison 3000 MH",
    fuelType: "Diesel",
    note: "Allegro RED diesel pusher — not Ford F53 V10 gas",
  },
  {
    yearMin: 2014,
    yearEnd: 2017,
    makeIncludes: "tiffin",
    modelIncludes: "allegro red",
    engine: "Cummins ISB / B6.7 360HP",
    horsepower: 360,
    torqueLbFt: 800,
    chassis: "Freightliner XC / XCR raised-rail",
    transmission: "Allison 3000 MH",
    fuelType: "Diesel",
    note: "2014–2017 Allegro RED mid-diesel — not ISL 8.9 / not L9 flagship",
  },
  {
    yearMin: 2014,
    yearEnd: 2017,
    makeIncludes: "tiffin",
    modelIncludes: "allegro red 340",
    engine: "Cummins ISB / B6.7 360HP",
    horsepower: 360,
    torqueLbFt: 800,
    chassis: "Freightliner XC / XCR raised-rail",
    transmission: "Allison 3000 MH",
    fuelType: "Diesel",
    note: "RED 340 2014–2017 — mid-diesel only",
  },
  {
    yearMin: 2018,
    yearEnd: 2026,
    makeIncludes: "tiffin",
    modelIncludes: "allegro red 340",
    engine: "Cummins B6.7 360HP",
    horsepower: 360,
    torqueLbFt: 800,
    chassis: "Freightliner XC-Series",
    transmission: "Allison 3000 MH",
    fuelType: "Diesel",
    note: "RED 340 mid-diesel — not L9/ISL bus class",
  },
  {
    yearMin: 2019,
    yearEnd: 2026,
    makeIncludes: "tiffin",
    modelIncludes: "allegro bus",
    engine: "Cummins L9 450HP (X12 optional)",
    horsepower: 450,
    torqueLbFt: 1250,
    chassis: "Tiffin PowerGlide",
    transmission: "Allison 3000 MH",
    fuelType: "Diesel",
  },
  {
    yearMin: 2016,
    yearEnd: 2026,
    makeIncludes: "tiffin",
    modelIncludes: "phaeton",
    floorplanIncludes: "37bh",
    engine: "Cummins L9 380HP",
    horsepower: 380,
    torqueLbFt: 1150,
    chassis: "Freightliner / Tiffin PowerGlide (by option)",
    transmission: "Allison 3000 MH 6-speed",
    fuelType: "Diesel",
    note:
      "37BH Phaeton OEM: L9 380 / 1,150 only — 450 was NOT offered on 37BH.",
  },
  {
    yearMin: 2016,
    yearEnd: 2026,
    makeIncludes: "tiffin",
    modelIncludes: "phaeton",
    floorplanIncludes: "44oh",
    engine: "Cummins L9 380HP (450 optional on tag axle)",
    horsepower: 380,
    torqueLbFt: 1150,
    chassis: "Freightliner / Tiffin PowerGlide (by option)",
    transmission: "Allison 3000 MH 6-speed",
    fuelType: "Diesel",
    note: "44OH — 380 standard; 450 may be available. Confirm build.",
  },
  {
    yearMin: 2016,
    yearEnd: 2026,
    makeIncludes: "tiffin",
    modelIncludes: "phaeton",
    engine: "Cummins L9 380HP",
    horsepower: 380,
    torqueLbFt: 1150,
    chassis: "Freightliner / Tiffin PowerGlide (by option)",
    transmission: "Allison 3000 MH 6-speed",
    fuelType: "Diesel",
    note:
      "Phaeton brochure default L9 380/1150. 450 only on select floorplans (not 37BH).",
  },
  {
    yearMin: 2020,
    yearEnd: 2026,
    makeIncludes: "newmar",
    modelIncludes: "ventana",
    floorplanIncludes: "4037",
    engine: "Cummins L9 400HP",
    horsepower: 400,
    torqueLbFt: 1250,
    chassis: "Freightliner XCR Tag / Spartan K2 Tag",
    transmission: "Allison 3000 MH",
    fuelType: "Diesel",
    note: "Ventana 40-ft class — OEM L9 400/1250 (not B6.7 360)",
  },
  {
    yearMin: 2020,
    yearEnd: 2026,
    makeIncludes: "newmar",
    modelIncludes: "ventana",
    floorplanIncludes: "4041",
    engine: "Cummins L9 400HP",
    horsepower: 400,
    torqueLbFt: 1250,
    chassis: "Freightliner XCR Tag / Spartan K2 Tag",
    transmission: "Allison 3000 MH",
    fuelType: "Diesel",
    note: "Ventana 40-ft class — OEM L9 400/1250",
  },
  {
    yearMin: 2020,
    yearEnd: 2026,
    makeIncludes: "newmar",
    modelIncludes: "ventana",
    floorplanIncludes: "4369",
    engine: "Cummins L9 400HP",
    horsepower: 400,
    torqueLbFt: 1250,
    chassis: "Freightliner XCR Tag / Spartan K2 Tag",
    transmission: "Allison 3000 MH",
    fuelType: "Diesel",
    note: "Ventana 43-ft class — OEM L9 400/1250",
  },
  {
    yearMin: 2020,
    yearEnd: 2026,
    makeIncludes: "newmar",
    modelIncludes: "ventana",
    floorplanIncludes: "4310",
    engine: "Cummins L9 400HP",
    horsepower: 400,
    torqueLbFt: 1250,
    chassis: "Freightliner XCR Tag / Spartan K2 Tag",
    transmission: "Allison 3000 MH",
    fuelType: "Diesel",
    note: "Ventana 43-ft class — OEM L9 400/1250",
  },
  {
    yearMin: 2020,
    yearEnd: 2026,
    makeIncludes: "newmar",
    modelIncludes: "ventana",
    floorplanIncludes: "3436",
    engine: "Cummins B6.7 360HP",
    horsepower: 360,
    torqueLbFt: 800,
    chassis: "Freightliner XCR / Spartan K2",
    transmission: "Allison 3000 MH",
    fuelType: "Diesel",
    note: "Ventana 34-ft class — OEM B6.7 360/800 (not L9)",
  },
  {
    yearMin: 2020,
    yearEnd: 2026,
    makeIncludes: "newmar",
    modelIncludes: "ventana",
    floorplanIncludes: "3717",
    engine: "Cummins B6.7 360HP",
    horsepower: 360,
    torqueLbFt: 800,
    chassis: "Freightliner XCR / Spartan K2",
    transmission: "Allison 3000 MH",
    fuelType: "Diesel",
    note: "Ventana 37-ft class — OEM B6.7 360/800",
  },
  // NO model-wide Ventana pin that forces 360 on every plan
  {
    yearMin: 2022,
    yearEnd: 2026,
    makeIncludes: "newmar",
    modelIncludes: "new aire",
    engine: "Cummins L9 450HP",
    horsepower: 450,
    torqueLbFt: 1250,
    chassis: "Freightliner / Spartan K2 (by option)",
    transmission: "Allison 3000 MH",
    fuelType: "Diesel",
    note: "Recent New Aire — L9 ~450/1250 (not B6.7 360)",
  },
  {
    yearMin: 2014,
    yearEnd: 2018,
    makeIncludes: "newmar",
    modelIncludes: "new aire",
    engine: "Cummins B6.7 / ISB 360HP",
    horsepower: 360,
    torqueLbFt: 800,
    chassis: "Freightliner XCS",
    transmission: "Allison 3000 MH",
    fuelType: "Diesel",
    note: "Early New Aire — B6.7/ISB 360/800",
  },
  // Fleetwood Bounder / Southwind gas V10 era
  {
    yearMin: 2005,
    yearEnd: 2015,
    makeIncludes: "fleetwood",
    modelIncludes: "bounder",
    engine: "Ford Triton V10 6.8L",
    horsepower: 320,
    chassis: "Ford F53",
    fuelType: "Gas",
    note: "2005–2015 Bounder — V10 era (not 7.3 Godzilla)",
  },
  {
    yearMin: 2005,
    yearEnd: 2015,
    makeIncludes: "fleetwood",
    modelIncludes: "southwind",
    engine: "Ford Triton V10 6.8L",
    horsepower: 320,
    chassis: "Ford F53",
    fuelType: "Gas",
    note: "2005–2015 gas Class A — Triton V10",
  },
  {
    yearMin: 2005,
    yearEnd: 2015,
    makeIncludes: "tiffin",
    modelIncludes: "allegro bus",
    engine: "Cummins ISL / ISB diesel (era)",
    horsepower: 380,
    chassis: "Freightliner / PowerGlide (by year)",
    fuelType: "Diesel",
    note: "2005–2015 Allegro Bus — confirm ISL rating on build sheet",
  },
  {
    yearMin: 2005,
    yearEnd: 2015,
    makeIncludes: "tiffin",
    modelIncludes: "phaeton",
    engine: "Cummins ISL / ISB diesel (era)",
    horsepower: 380,
    chassis: "Freightliner / PowerGlide (by year)",
    fuelType: "Diesel",
  },
  {
    yearMin: 2005,
    yearEnd: 2015,
    makeIncludes: "tiffin",
    modelIncludes: "allegro open road",
    engine: "Ford 6.8L V10 / E-450 (era)",
    horsepower: 305,
    chassis: "Ford F53 / E-450",
    fuelType: "Gas",
  },
  {
    yearMin: 2016,
    yearEnd: 2026,
    makeIncludes: "dynamax",
    modelIncludes: "isata 3",
    engine: "Mercedes-Benz 2.0L I4 turbodiesel",
    horsepower: 211,
    chassis: "Mercedes-Benz Sprinter",
    fuelType: "Diesel",
    note: "Isata 3 — Sprinter diesel (team catalog corrected)",
  },
  // Discovery modern pin (duplicate-safe longer window)
  {
    yearMin: 2015,
    yearEnd: 2026,
    makeIncludes: "fleetwood",
    modelIncludes: "discovery",
    engine: "Cummins B6.7 (ISB) 360HP",
    horsepower: 360,
    torqueLbFt: 800,
    chassis: "Freightliner XC-Series",
    transmission: "Allison 3000 MH",
    fuelType: "Diesel",
    note: "Regular Discovery — not LXE / not ISL 8.9",
  },
];

/** Patterns that prove a Live Grok narrative stole a flagship/sibling powertrain. */
const FLAGSHIP_ENGINE_RE =
  /\b(isl\s*8\.?9|isl\b|l9\s*450|x15|x12\s*500|1[,.]?250\s*lb|1250\s*lb|450\s*hp)\b/i;
const GAS_V10_RE =
  /\b(triton|v10|6\.8l\s*v10|ford\s*f-?53|torqshift|godzilla)\b/i;
const MID_DIESEL_RE = /\b(isb|b6\.7|b6\.7|340\s*hp|360\s*hp)\b/i;

export function findPowertrainCorrection(
  year: string | number,
  make: string,
  model: string,
  floorplan?: string,
): PowertrainCorrection | null {
  const y = typeof year === "number" ? year : parseInt(String(year), 10);
  if (!Number.isFinite(y)) return null;
  const mk = make.toLowerCase();
  const md = model.toLowerCase().replace(/\s+/g, " ").trim();
  const fp = (floorplan || "").toLowerCase();

  // Prefer floorplan-specific pins, then longer modelIncludes
  const hits = POWERTRAIN_CORRECTIONS.filter((c) => {
    if (y < c.yearMin || y > c.yearEnd) return false;
    if (!mk.includes(c.makeIncludes.toLowerCase())) return false;
    if (!md.includes(c.modelIncludes.toLowerCase())) return false;
    if (c.floorplanIncludes) {
      const cfp = c.floorplanIncludes.toLowerCase().replace(/[\s\-_/]/g, "");
      const nfp = fp.replace(/[\s\-_/]/g, "");
      if (!nfp || (!nfp.includes(cfp) && !cfp.includes(nfp))) return false;
    }
    // Avoid matching "discovery" rule on "discovery lxe" when a more specific exists
    if (c.modelIncludes === "discovery" && md.includes("discovery lxe")) {
      return false;
    }
    // Avoid matching bare "allegro red" on "allegro red 340/360"
    if (
      c.modelIncludes === "allegro red" &&
      (md.includes("allegro red 340") ||
        md.includes("allegro red 360") ||
        md.includes("allegro red340") ||
        md.includes("allegro red360"))
    ) {
      return false;
    }
    // Avoid matching bare "reatta" on "reatta xl" if needed later
    if (c.modelIncludes === "reatta" && md.includes("reatta xl")) {
      return false;
    }
    // Vision diesel trim is a different product
    if (
      c.modelIncludes === "vision" &&
      (md.includes("vision xl") || md.includes("diesel"))
    ) {
      return false;
    }
    return true;
  }).sort((a, b) => {
    const af = a.floorplanIncludes ? 1 : 0;
    const bf = b.floorplanIncludes ? 1 : 0;
    if (bf !== af) return bf - af;
    return b.modelIncludes.length - a.modelIncludes.length;
  });

  return hits[0] ?? null;
}

/** True when Live Grok engine text conflicts with a brochure pin. */
export function powertrainConflictsWithPin(
  pin: PowertrainCorrection,
  engine: string | null | undefined,
  horsepower?: number | null,
): boolean {
  if (!engine) return false;
  const live = engine.toLowerCase();
  const pinned = pin.engine.toLowerCase();
  const pinIsMid =
    MID_DIESEL_RE.test(pinned) && !/isl|l9|x15|x12/.test(pinned);
  const liveIsFlagship =
    FLAGSHIP_ENGINE_RE.test(live) ||
    (horsepower != null &&
      pin.horsepower <= 380 &&
      horsepower >= 450);
  if (pinIsMid && liveIsFlagship) return true;
  if (
    /cummins|diesel|isb|b6/.test(pinned) &&
    GAS_V10_RE.test(live) &&
    !/cummins|isb|b6|l9|isl/.test(live)
  ) {
    return true;
  }
  if (
    pin.fuelType === "Gas" &&
    /cummins|diesel|isb|l9|isl/.test(live)
  ) {
    return true;
  }
  return false;
}

/**
 * Rewrite overview / feature chips that still name the wrong powertrain.
 * Keeps market/lifestyle language; strips sibling-engine claims.
 */
export function sanitizeNarrativeForPin(
  pin: PowertrainCorrection,
  text: string | null | undefined,
): string | null {
  if (!text) return text ?? null;
  let t = text;
  const eng = pin.engine;
  const hp = pin.horsepower;
  const tq = pin.torqueLbFt;

  // Replace common wrong powertrains with the pin label
  t = t.replace(
    /Cummins\s+ISL(?:\s*8\.?9L?)?(?:\s+\d+\s*HP)?(?:\s*\/\s*[\d,]+\s*lb-?ft)?/gi,
    eng,
  );
  t = t.replace(
    /Cummins\s+L9(?:\s+\d+\s*HP)?(?:\s*\/\s*[\d,]+\s*lb-?ft)?/gi,
    eng,
  );
  t = t.replace(
    /Ford\s+Triton\s+V10(?:\s*6\.8L)?(?:\s*\([^)]*\))?/gi,
    eng,
  );
  t = t.replace(/Ford\s+F-?53(?:\s+chassis)?/gi, pin.chassis || "chassis");
  t = t.replace(/\b450\s*HP\b/gi, `${hp} HP`);
  t = t.replace(/\b1[,.]?250\s*lb-?ft\b/gi, tq ? `${tq.toLocaleString()} lb-ft` : `${hp} HP class`);
  t = t.replace(/\b320\s*HP\b/gi, `${hp} HP`);
  t = t.replace(/\b832\s*lb-?ft\b/gi, tq ? `${tq.toLocaleString()} lb-ft` : "");

  // Drop "early gas Red / gas F53" myths when pin is diesel RED
  if (pin.fuelType === "Diesel" || /cummins|isb|b6/i.test(pin.engine)) {
    t = t.replace(/\bearly\s+years?\s+gas\s+F-?53[^.]*\./gi, "");
    t = t.replace(/\bearly\s+gas\s+Red\b/gi, "diesel Allegro RED");
    t = t.replace(/\bgas\s+F-?53[^.]*\./gi, "");
    t = t.replace(/\b\(gas years\)/gi, "");
  }

  return t.replace(/\s{2,}/g, " ").trim() || null;
}

export function sanitizeFeaturesForPin(
  pin: PowertrainCorrection,
  features: string[] | null | undefined,
): string[] {
  if (!features?.length) return [];
  return features
    .map((f) => sanitizeNarrativeForPin(pin, f) || "")
    .filter(Boolean)
    .filter((f) => {
      // Drop chips that still scream wrong flagship after sanitize
      if (powertrainConflictsWithPin(pin, f)) return false;
      return true;
    })
    .slice(0, 8);
}
