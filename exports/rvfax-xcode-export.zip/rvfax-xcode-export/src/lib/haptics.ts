/**
 * Light tactile feedback for dials / dock taps.
 * Prefers Capacitor Haptics on native; falls back to Vibration API.
 */

type HapticsMod = {
  impact?: (opts: { style: string }) => Promise<void>;
  selectionChanged?: () => Promise<void>;
  selectionStart?: () => Promise<void>;
  selectionEnd?: () => Promise<void>;
  notification?: (opts: { type: string }) => Promise<void>;
};

let cached: HapticsMod | null | undefined;
let impactStyles: { Light?: string; Medium?: string; Heavy?: string } | null =
  null;
let loadPromise: Promise<HapticsMod | null> | null = null;

function canVibrate() {
  return (
    typeof navigator !== "undefined" &&
    typeof navigator.vibrate === "function"
  );
}

/** Short mechanical click via Vibration API. */
function vibrateTick(ms = 8) {
  try {
    if (canVibrate()) navigator.vibrate(ms);
  } catch {
    /* */
  }
}

async function loadHaptics(): Promise<HapticsMod | null> {
  if (cached !== undefined) return cached;
  if (loadPromise) return loadPromise;
  loadPromise = (async () => {
    if (typeof window === "undefined") {
      cached = null;
      return null;
    }
    try {
      // Optional native module — may be absent in web/dev.
      const mod = (await (
        Function('return import("@capacitor/haptics")')() as Promise<{
          Haptics?: HapticsMod;
          ImpactStyle?: { Light?: string; Medium?: string; Heavy?: string };
        }>
      ).catch(() => null));
      if (mod?.Haptics) {
        impactStyles = mod.ImpactStyle ?? null;
        cached = mod.Haptics;
        return cached;
      }
    } catch {
      /* */
    }
    cached = null;
    return null;
  })();
  return loadPromise;
}

/** Warm the native module so the first snap isn't delayed. */
export function preloadHaptics() {
  void loadHaptics();
}

export async function hapticLight() {
  const H = await loadHaptics();
  try {
    if (H?.impact) {
      await H.impact({ style: impactStyles?.Light ?? "LIGHT" });
      return;
    }
  } catch {
    /* */
  }
  vibrateTick(10);
}

export async function hapticMedium() {
  const H = await loadHaptics();
  try {
    if (H?.impact) {
      await H.impact({ style: impactStyles?.Medium ?? "MEDIUM" });
      return;
    }
  } catch {
    /* */
  }
  vibrateTick(16);
}

/**
 * Dial / picker snap — selection haptics when available (iOS),
 * otherwise light impact / short vibrate.
 */
export async function hapticSnap() {
  const H = await loadHaptics();
  try {
    if (H?.selectionChanged) {
      await H.selectionChanged();
      return;
    }
    if (H?.impact) {
      await H.impact({ style: impactStyles?.Light ?? "LIGHT" });
      return;
    }
  } catch {
    /* */
  }
  vibrateTick(8);
}

/** Call once when a dial interaction begins. */
export async function hapticSnapStart() {
  const H = await loadHaptics();
  try {
    if (H?.selectionStart) {
      await H.selectionStart();
      return;
    }
  } catch {
    /* */
  }
}

export async function hapticSnapEnd() {
  const H = await loadHaptics();
  try {
    if (H?.selectionEnd) {
      await H.selectionEnd();
      return;
    }
  } catch {
    /* */
  }
}
