/**
 * Imported backdrops — Vite hashes + ships these in production.
 * Single seal bitmap shared across suite (no duplicate JPEG bundles).
 */
import sharedPrestige from "@/assets/backdrops/shared-prestige.jpg";
import rvtripsAmerica from "@/assets/backdrops/rvtrips-america.jpg";
import rvtripsMapPanel from "@/assets/backdrops/rvtrips-map-panel.jpg";

/** Suite default — Fax, Cal, Tow, Premium, Grok, detail */
export const SHARED_PRESTIGE_BACKDROP = sharedPrestige;

/** Card / detail media placeholder */
export const RV_CARD_MEDIA = sharedPrestige;

/** Metallic North America globe — RvTrips */
export const RVTRIPS_AMERICA_BACKDROP = rvtripsAmerica;

/** Navigate map panel */
export const RVTRIPS_MAP_PANEL = rvtripsMapPanel;

/** Full-bleed seal ray splash (public, adaptive quality) */
export const RVFOX_LAUNCH_SEAL = "/assets/splash/rvfox-launch-seal.mp4";
export const RVFOX_LAUNCH_SEAL_LITE = "/assets/splash/rvfox-launch-seal-lite.mp4";
export const RVFOX_LAUNCH_SEAL_ULTRA = "/assets/splash/rvfox-launch-seal-ultra.mp4";
