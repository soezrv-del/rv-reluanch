import { createFileRoute } from "@tanstack/react-router";
import { DEFAULT_WORKER_URL } from "@/lib/rvgrok/types";

/**
 * POST /api/rvfax/compare
 * { coaches: [{ year, make, model, floorplan?, type?, highlights? }] }
 * → AI narrative comparing 2–3 RVs for a buyer.
 */

function workerBase() {
  return (
    process.env.CLOUDFLARE_WORKER_URL ||
    process.env.VITE_CLOUDFLARE_WORKER_URL ||
    DEFAULT_WORKER_URL
  ).replace(/\/$/, "");
}

function extractText(data: unknown): string {
  const d = data as {
    choices?: Array<{ message?: { content?: string }; text?: string }>;
    content?: string;
    message?: string;
  };
  return String(
    d?.choices?.[0]?.message?.content ||
      d?.choices?.[0]?.text ||
      d?.content ||
      d?.message ||
      "",
  );
}

type CoachIn = {
  year: string;
  make: string;
  model: string;
  floorplan?: string;
  type?: string;
  rating?: number;
  engine?: string;
  chassis?: string;
  length?: string;
  retailHigh?: number;
  tradeIn?: number;
};

async function callGrok(prompt: string): Promise<string | null> {
  const base = workerBase();
  const urls = [`${base}/chat`, `${base}/rvgrok-chat`, `${base}/`];
  for (const url of urls) {
    try {
      const resp = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [
            {
              role: "system",
              content:
                "You are RVFAX Pro compare analyst. Write clear, premium buyer guidance. No markdown fences. Use short paragraphs and bullet points with • only.",
            },
            { role: "user", content: prompt },
          ],
          agentMode: false,
          stream: false,
        }),
      });
      if (resp.status === 404 || resp.status === 405) continue;
      if (!resp.ok) continue;
      const ctype = resp.headers.get("content-type") || "";
      if (ctype.includes("text/event-stream")) {
        const text = await resp.text();
        let acc = "";
        for (const line of text.split("\n")) {
          if (!line.startsWith("data: ")) continue;
          const raw = line.slice(6).trim();
          if (!raw || raw === "[DONE]") continue;
          try {
            const p = JSON.parse(raw);
            acc +=
              p?.choices?.[0]?.delta?.content ||
              p?.choices?.[0]?.message?.content ||
              p?.content ||
              "";
          } catch {
            /* */
          }
        }
        if (acc.trim()) return acc.trim();
        continue;
      }
      const data = await resp.json();
      const text = extractText(data).trim();
      if (text) return text;
    } catch {
      /* */
    }
  }

  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) return null;
  try {
    const resp = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-3",
        messages: [
          {
            role: "system",
            content:
              "You are RVFAX Pro compare analyst. Clear premium buyer guidance. No markdown fences.",
          },
          { role: "user", content: prompt },
        ],
        temperature: 0.35,
      }),
    });
    if (!resp.ok) return null;
    return extractText(await resp.json()).trim() || null;
  } catch {
    return null;
  }
}

function localSummary(coaches: CoachIn[]): string {
  const names = coaches.map(
    (c) =>
      `${c.year} ${c.make} ${c.model}${c.floorplan ? ` ${c.floorplan}` : ""}`,
  );
  const lines = [
    `Side-by-side of ${names.join(" · ")}.`,
    ``,
    `• Use the green cells for clear advantages (higher rating, more CCC, better MPG, lower used ask where priced).`,
    `• Red cells flag relative weak spots among this set — not absolute deal-breakers.`,
    `• Match class & fuel first (gas Class A vs diesel pusher is a lifestyle choice, not a pure score).`,
    `• Always confirm floorplan living layout, UVW on the unit sticker, and a PPI before you buy.`,
    ``,
    `Live Grok summary was not available — this is a structured RVFAX checklist. Connect the chat worker for a full narrative.`,
  ];
  return lines.join("\n");
}

export const Route = createFileRoute("/api/rvfax/compare")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let body: { coaches?: CoachIn[] } = {};
        try {
          body = (await request.json()) as typeof body;
        } catch {
          return Response.json({ error: "Invalid JSON" }, { status: 400 });
        }
        const coaches = (body.coaches || []).slice(0, 3);
        if (coaches.length < 2) {
          return Response.json(
            { error: "Select 2 or 3 coaches to compare." },
            { status: 400 },
          );
        }

        const prompt = [
          `Compare these ${coaches.length} used RVs for a serious buyer.`,
          `Be specific: who each coach is for, major tradeoffs, and a clear recommendation if one wins overall.`,
          `Cover: living comfort, powertrain/chassis, ownership cost (fuel, service), used-market value, and deal-breakers.`,
          `Coaches:`,
          JSON.stringify(coaches, null, 2),
          ``,
          `Structure:`,
          `1) One-line overview`,
          `2) Best for… (each coach, 1 line)`,
          `3) Key differences (bullets)`,
          `4) Bottom line recommendation (2–3 sentences)`,
        ].join("\n");

        const text = (await callGrok(prompt)) || localSummary(coaches);
        return Response.json({
          summary: text,
          live: Boolean(text && !text.includes("Live Grok summary was not")),
          generatedAt: new Date().toISOString(),
        });
      },
    },
  },
});
