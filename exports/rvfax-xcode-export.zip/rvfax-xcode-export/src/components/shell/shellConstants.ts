import type { AppTab } from "./BottomTabs";

/** Dock order — Facts home, Grok on the right */
export const TAB_ORDER = [
  "rvfax",
  "rvcal",
  "rvtow",
  "rvtrips",
  "rvgrok",
] as const satisfies readonly AppTab[];

/** One hero accent per page — premium color discipline */
export const PAGE_ACCENT: Record<AppTab, "sapphire" | "ruby" | "gold"> = {
  rvfax: "sapphire",
  rvcal: "sapphire",

  rvtow: "sapphire",
  rvtrips: "sapphire",
  rvgrok: "sapphire",

  more: "gold",
};

export const PAGE_COPY: Record<
  AppTab,
  { title: string; line: string; badge?: string }
> = {
  rvgrok: {
    title: "RvGROK",
    line: "Voice + chat co-pilot for real RV decisions.",
    badge: "HOME",
  },
  rvfax: {
    title: "RvFACTS",
    line: "Specs · recalls · brochure truth before you buy.",
    badge: "LIVE",
  },
  rvcal: {
    title: "RvCAL",
    line: "Payments, tax by ZIP, and credit-aware lenders.",
    badge: "LIVE",
  },
  rvtow: {
    title: "RvTOW",
    line: "Truck · SUV · VIN decode for safe tow math.",
    badge: "LIVE",
  },
  rvtrips: {
    title: "RvTRIPS",
    line: "RV-aware routes, pack list, and coach profile.",
    badge: "LIVE",
  },
  more: {
    title: "PREMIUM",
    line: "Voice settings · NHTSA · suite tools.",
    badge: "SUITE",
  },
};
