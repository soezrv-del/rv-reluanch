import { useEffect, useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  ArrowLeft,
  Calculator,
  CheckCircle2,
  ExternalLink,
  FileText,
  Heart,
  Info,
  Loader2,
  MapPin,
  Printer,
  Sparkles,
} from "lucide-react";
import type { RVResult } from "@/lib/rv/catalog";
import {
  estimateMarket,
  formatMoney,
  getFloorplansForYear,
  ratingFor,
} from "@/lib/rv/catalog";
import { buildBrochureSpecs } from "@/lib/rv/brochureSpecs";
import {
  findPowertrainCorrection,
  sanitizeFeaturesForPin,
  sanitizeNarrativeForPin,
} from "@/lib/rv/powertrainCorrections";
import {
  formatHardHorsepower,
  formatHardTorque,
  resolveHardPowertrain,
  trustBadgeLabel,
  type PowertrainTrust,
} from "@/lib/rv/livePowertrainGuard";
import {
  exportLocalSpecOverridesJson,
  findLocalSpecOverride,
  removeLocalSpecOverride,
  saveLocalSpecOverride,
} from "@/lib/rv/localSpecOverrides";
import {
  exportProposedPatchesJson,
  upsertProposedPatch,
  type CatalogPowertrainPatch,
} from "@/lib/rv/catalogPatch";
import { getMaintenanceSchedule } from "@/lib/rv/rvData";
import {
  fetchLiveDossier,
  liveMarketLadder,
  mergeLiveIntoDisplay,
  peekVerifiedDossier,
  refreshCoachDossierCache,
  type LiveDossier,
} from "@/lib/rv/liveDossier";
import { fetchRecallsViaApi } from "@/lib/nhtsa/recalls";
import type { NhtsaComplaint, NhtsaRecall } from "@/lib/nhtsa/recalls";
import { buildReportId, valueFactors } from "@/lib/rv/reportMeta";
import { exportVehicleReport } from "@/lib/rv/exportReport";
import {
  fetchLocalInventory,
  loadInventoryZip,
  saveInventoryZip,
} from "@/lib/marketcheck/client";
import type { McListingCard } from "@/lib/marketcheck/types";
import { useShellNavOptional } from "@/components/shell/ShellNavContext";
import { usePullToReset } from "@/lib/hooks/usePullToReset";
import { PullResetHint } from "@/components/shell/PullResetHint";
import { SHARED_PRESTIGE_BACKDROP } from "@/assets/backdrops";
import { SuiteBackdrop } from "@/components/shell/SuitePage";
import { cn } from "@/lib/utils";

/**
 * Vehicle History Report — catalog paints instantly; Live Grok updates soft fields.
 * Phase 1: year-banded powertrain always paints from the selected wizard year.
 * Brochure powertrain pins always win over Live Grok (prevents ISL/V10 hallucinations).
 */
export function RvDetail({
  result,
  onBack,
  saved,
  onToggleSave,
  onAskGrok,
}: {
  result: RVResult;
  onBack: () => void;
  saved: boolean;
  onToggleSave: () => void;
  onAskGrok: () => void;
}) {
  const { data, year, make, model, floorplan } = result;
  const catalogMarket = estimateMarket(data, year, floorplan);
  const rating = ratingFor(make, model, year);
  const [correctBump, setCorrectBump] = useState(0);
  const brochure = useMemo(
    () => buildBrochureSpecs(data, year, make, model, floorplan || ""),
    // correctBump forces re-read of local overrides
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [data, year, make, model, floorplan, correctBump],
  );
  const yearFloorplans = useMemo(
    () => getFloorplansForYear(year, make, model),
    [year, make, model],
  );
  const maintenance = useMemo(() => getMaintenanceSchedule(data), [data]);

  const reportId = useMemo(
    () => buildReportId(year, make, model),
    [year, make, model],
  );
  const generatedAt = useMemo(
    () =>
      new Date().toLocaleString(undefined, {
        dateStyle: "medium",
        timeStyle: "short",
      }),
    [],
  );

  const [liveRecalls, setLiveRecalls] = useState<NhtsaRecall[]>([]);
  const [liveDefects, setLiveDefects] = useState<NhtsaComplaint[]>([]);
  const [recallSearchNote, setRecallSearchNote] = useState<string | null>(null);
  const [recallLoading, setRecallLoading] = useState(true);
  const [recallError, setRecallError] = useState<string | null>(null);

  const [live, setLive] = useState<LiveDossier | null>(null);
  const [liveLoading, setLiveLoading] = useState(true);
  const [liveError, setLiveError] = useState<string | null>(null);
  const [liveRetry, setLiveRetry] = useState(0);

  const [exportBusy, setExportBusy] = useState(false);
  const [exportMsg, setExportMsg] = useState<string | null>(null);
  const [openMaint, setOpenMaint] = useState(false);
  const [correctOpen, setCorrectOpen] = useState(false);
  const [correctEngine, setCorrectEngine] = useState("");
  const [correctHp, setCorrectHp] = useState("");
  const [correctTorque, setCorrectTorque] = useState("");
  const [correctChassis, setCorrectChassis] = useState("");
  const [correctTrans, setCorrectTrans] = useState("");
  const [correctFuel, setCorrectFuel] = useState("");
  const [correctNote, setCorrectNote] = useState("");
  const [correctMsg, setCorrectMsg] = useState<string | null>(null);
  const [researchBusy, setResearchBusy] = useState(false);
  const [researchMsg, setResearchMsg] = useState<string | null>(null);
  const shellNav = useShellNavOptional();
  const scrollRef = useRef<HTMLDivElement | null>(null);

  const [invZip, setInvZip] = useState(() => loadInventoryZip() || "98402");
  const [invRadius, setInvRadius] = useState(100);
  const [invLoading, setInvLoading] = useState(false);
  const [invError, setInvError] = useState<string | null>(null);
  const [invListings, setInvListings] = useState<McListingCard[]>([]);
  const [invSearched, setInvSearched] = useState(false);

  const pullHint = usePullToReset(scrollRef, onBack);

  useEffect(() => {
    const ctrl = new AbortController();
    setRecallLoading(true);
    setRecallError(null);
    setRecallSearchNote(null);
    fetchRecallsViaApi(year, make, model, ctrl.signal).then((res) => {
      if (ctrl.signal.aborted) return;
      if (!res.ok) {
        if (res.aborted) return;
        setRecallError(res.error);
        setLiveRecalls([]);
        setLiveDefects([]);
        setRecallLoading(false);
        return;
      }
      setLiveRecalls(res.data.recalls);
      setLiveDefects(res.data.defects ?? []);
      setRecallSearchNote(res.data.searchNote ?? null);
      setRecallLoading(false);
    });
    return () => ctrl.abort();
  }, [year, make, model]);

  useEffect(() => {
    let cancelled = false;
    const ctrl = new AbortController();
    setLiveLoading(true);
    setLiveError(null);

    // Instant accurate paint if we've verified this coach before
    const peek = peekVerifiedDossier(year, make, model, floorplan);
    if (peek) {
      setLive(peek);
    } else {
      // Phase 3.4: do NOT clear year-band catalog paint — leave live null
      // so hard specs stay from brochure until Live succeeds
      setLive(null);
    }

    // Phase 3.2 — inject year+floorplan brochure as candidate truth for dossier
    const catalogCandidate = {
      engine: brochure.engine,
      horsepower: brochure.horsepower,
      torque: brochure.torque,
      chassis: brochure.chassis,
      transmission: brochure.transmission,
      fuelType: data.fuelType,
      type: data.type,
      dataSource: brochure.dataSource,
      accuracyNote: brochure.accuracyNote,
      floorplan: floorplan || null,
      lengthFt: brochure.lengthFt,
      gvwr: brochure.gvwr,
    };

    fetchLiveDossier(
      year,
      make,
      model,
      floorplan,
      ctrl.signal,
      catalogCandidate,
    )
      .then((res) => {
        if (cancelled) return;
        if (!res.ok) {
          if (res.aborted) return;
          // Keep peek if any; otherwise leave live null (catalog year-band stays)
          setLiveError(res.error);
          if (!peek) {
            /* live stays null — year-true catalog remains on screen */
          }
          return;
        }
        setLive(res.data);
        setLiveError(null);
      })
      .catch((e: unknown) => {
        if (cancelled) return;
        setLiveError(e instanceof Error ? e.message : "Live lookup failed");
        // Phase 3.4 — never blank hard facts; catalog brochure remains
      })
      .finally(() => {
        if (!cancelled) setLiveLoading(false);
      });

    return () => {
      cancelled = true;
      ctrl.abort();
    };
  }, [year, make, model, floorplan, liveRetry, brochure, data.fuelType, data.type]);

  // Instant catalog brochure → live Grok overwrites fields when ready
  const catalogSpecs = useMemo(
    () => ({
      engine: brochure.engine,
      horsepower: brochure.horsepower,
      torque: brochure.torque,
      transmission: brochure.transmission,
      chassis: brochure.chassis,
      hitchOrPin: brochure.hitchOrPin,
      fuelCapacity: brochure.fuelCapacity,
      lengthFt: brochure.lengthFt,
      exteriorWidth: brochure.exteriorWidth,
      exteriorHeight: brochure.exteriorHeight,
      interiorHeight: brochure.interiorHeight,
      gvwr: brochure.gvwr,
      uvw: brochure.uvw,
      ccc: brochure.ccc,
      slideouts: brochure.slideouts,
      sleeps: brochure.sleeps,
      freshWater: brochure.freshWater,
      grayWater: brochure.grayWater,
      blackWater: brochure.blackWater,
      generator: brochure.generator,
      mpgHighway: brochure.mpgHighway,
      warranty: brochure.warranty,
    }),
    [brochure],
  );

  const isEstimate = !live?.live;
  const brochurePinned = brochure.dataSource === "oem-year";
  const powertrainPin = useMemo(
    () => findPowertrainCorrection(year, make, model, floorplan || ""),
    [year, make, model, floorplan],
  );

  /** Phase 2 guard: pin / catalog hard facts; Live only fills empties if validated */
  const powertrainGuard = useMemo(
    () =>
      resolveHardPowertrain({
        year,
        make,
        model,
        floorplan: floorplan || "",
        catalog: {
          engine: brochure.engine,
          horsepower: brochure.horsepower,
          torque: brochure.torque,
          chassis: brochure.chassis,
          transmission: brochure.transmission,
          fuelType: data.fuelType,
          type: data.type,
        },
        live: live?.live ? live : null,
      }),
    // correctBump refreshes local override pin
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [year, make, model, floorplan, brochure, data.fuelType, data.type, live, correctBump],
  );

  const powertrainTrust: PowertrainTrust = powertrainGuard.trust;

  const specs = useMemo(() => {
    const hardHp =
      formatHardHorsepower(powertrainGuard.hard.horsepower) ||
      catalogSpecs.horsepower;
    const hardTq =
      formatHardTorque(powertrainGuard.hard.torqueLbFt) || catalogSpecs.torque;

    const hardOverride = {
      engine: powertrainGuard.hard.engine || catalogSpecs.engine,
      horsepower: hardHp,
      torque: hardTq,
      chassis: powertrainGuard.hard.chassis || catalogSpecs.chassis,
      transmission:
        powertrainGuard.hard.transmission || catalogSpecs.transmission,
    };

    // Soft fields from Live; hard fields from guard (never stomped)
    const merged = mergeLiveIntoDisplay(
      catalogSpecs,
      live?.live ? live : null,
      {
        lockPowertrainFromCatalog: true,
        hardOverride,
      },
    );

    if (brochurePinned) {
      return {
        ...merged,
        lengthFt: catalogSpecs.lengthFt || merged.lengthFt,
        exteriorWidth: catalogSpecs.exteriorWidth || merged.exteriorWidth,
        exteriorHeight: catalogSpecs.exteriorHeight || merged.exteriorHeight,
        interiorHeight: catalogSpecs.interiorHeight || merged.interiorHeight,
        gvwr: catalogSpecs.gvwr || merged.gvwr,
        uvw: catalogSpecs.uvw || merged.uvw,
        ccc: catalogSpecs.ccc || merged.ccc,
        freshWater: catalogSpecs.freshWater || merged.freshWater,
        grayWater: catalogSpecs.grayWater || merged.grayWater,
        blackWater: catalogSpecs.blackWater || merged.blackWater,
      };
    }
    return merged;
  }, [catalogSpecs, live, brochurePinned, powertrainGuard]);

  const displayRating =
    live?.live && live.ratingEstimate && live.ratingEstimate > 0
      ? live.ratingEstimate
      : rating;

  const liveLadder = liveMarketLadder(live?.live ? live : null);
  const market = useMemo(
    () =>
      liveLadder
        ? {
            tradeIn: liveLadder.tradeIn,
            retailLow: liveLadder.retailLow,
            retailHigh: liveLadder.retailHigh,
            msrpLo: liveLadder.msrpLo ?? catalogMarket.msrpLo,
            msrpHi: liveLadder.msrpHi ?? catalogMarket.msrpHi,
            segment: catalogMarket.segment,
            ageYears: catalogMarket.ageYears,
          }
        : catalogMarket,
    [liveLadder, catalogMarket],
  );
  const marketIsLive = Boolean(liveLadder);

  const displayType =
    (powertrainGuard.hard.fuelType === "Diesel"
      ? data.type?.replace(/gas/i, "Diesel") || "Class A Diesel"
      : powertrainGuard.hard.fuelType === "Gas"
        ? data.type?.replace(/diesel/i, "Gas") || "Class A Gas"
        : null) ||
    // Live rvType is soft — ok to use when no pin/catalog fuel conflict
    (live?.live && live.rvType && powertrainTrust !== "pinned"
      ? live.rvType
      : null) ||
    data.type;

  const displayFuel =
    powertrainGuard.hard.fuelType ||
    data.fuelType;

  const recallCount = recallLoading
    ? data.recalls
    : liveRecalls.length || data.recalls;

  const factors = useMemo(
    () =>
      valueFactors(
        market,
        displayRating,
        recallLoading ? 0 : liveRecalls.length,
        data.warrantyYears,
      ),
    [market, displayRating, recallLoading, liveRecalls.length, data.warrantyYears],
  );

  const floorplansShown = useMemo(() => {
    if (live?.live && live.floorplansThisYear?.length)
      return live.floorplansThisYear;
    if (yearFloorplans.length) return yearFloorplans;
    return data.floorplans || [];
  }, [live, yearFloorplans, data.floorplans]);

  const overviewText = useMemo(() => {
    const raw =
      (live?.live && live.overview) || data.description || null;
    if (!raw) return null;
    if (!powertrainPin) return raw;
    return sanitizeNarrativeForPin(powertrainPin, raw) || raw;
  }, [live, data.description, powertrainPin]);

  const featureChips = useMemo(() => {
    if (!live?.live || !live.keyFeatures?.length) return [];
    if (!powertrainPin) return live.keyFeatures.slice(0, 6);
    return sanitizeFeaturesForPin(powertrainPin, live.keyFeatures).slice(0, 6);
  }, [live, powertrainPin]);

  const runInventorySearch = async () => {
    const zip = invZip.trim();
    if (!/^\d{5}$/.test(zip)) {
      setInvError("Enter a 5-digit ZIP");
      return;
    }
    saveInventoryZip(zip);
    setInvLoading(true);
    setInvError(null);
    setInvSearched(true);
    const res = await fetchLocalInventory({
      year,
      make,
      model,
      zip,
      radius: invRadius,
    });
    setInvLoading(false);
    if (!res.ok) {
      setInvListings([]);
      setInvError(res.error || "Inventory search unavailable");
      return;
    }
    setInvListings(res.listings || []);
    if (!res.listings?.length) {
      setInvError("No local listings found");
    }
  };

  const invMedian = useMemo(() => {
    const prices = invListings
      .map((l) => l.price)
      .filter((n): n is number => typeof n === "number" && n > 0)
      .sort((a, b) => a - b);
    if (!prices.length) return null;
    return prices[Math.floor(prices.length / 2)]!;
  }, [invListings]);

  const exportPdf = async () => {
    if (exportBusy) return;
    setExportBusy(true);
    setExportMsg("Preparing PDF…");
    try {
      await new Promise((r) => requestAnimationFrame(() => r(null)));
      const res = await exportVehicleReport({
        reportElementId: "rvfax-vehicle-report",
        title: `RvFOX Pro · ${year} ${make} ${model}${floorplan ? ` ${floorplan}` : ""}`,
        subtitle: `Vehicle History Report · ${reportId} · ${generatedAt}`,
        filenameBase: `RvFOX-Pro-${year}-${make}-${model}`.replace(/\s+/g, "-"),
        meta: {
          year,
          make,
          model,
          floorplan: floorplan || undefined,
          tradeIn: formatMoney(market.tradeIn),
          retailLow: formatMoney(market.retailLow),
          retailHigh: formatMoney(market.retailHigh),
          rating: displayRating.toFixed(1),
          type: displayType,
          recallCount: recallLoading ? 0 : recallCount,
          reportId,
          preparedFor: "Client",
          factors: factors.map((f) => ({
            label: f.label,
            positive: f.positive,
          })),
          length: specs.lengthFt,
          slideouts: specs.slideouts,
          sleeps: specs.sleeps,
        },
      });
      if (!res.ok) setExportMsg(res.error);
      else if (res.method === "share")
        setExportMsg("Shared — pick Print or Save to Files for PDF");
      else if (res.method === "print")
        setExportMsg("Print dialog opened — choose Save as PDF");
      else if (res.method === "preview")
        setExportMsg("Preview open — tap Save as PDF / Print");
      else setExportMsg("Report downloaded — open it and Print → PDF");
    } catch (e) {
      setExportMsg(e instanceof Error ? e.message : "Export failed");
    } finally {
      setExportBusy(false);
    }
  };

  const confNote =
    live?.live && live.sourcesNote
      ? live.sourcesNote
      : liveLoading
        ? "Showing catalog now — Live Grok is refining specs & market in the background."
        : liveError
          ? `Live update failed (${liveError}). Catalog estimates remain — tap Retry.`
          : "Catalog estimates on screen. Tap Retry to refresh with Live Grok.";

  return (
    <div className="relative flex h-full flex-col overflow-hidden bg-bg text-white">
      <SuiteBackdrop src={SHARED_PRESTIGE_BACKDROP} />

      <div
        ref={scrollRef}
        data-app-scroll
        data-rvfax-scroll
        className="rv-scroll relative z-10 h-full overflow-y-auto overscroll-y-contain"
      >
        <PullResetHint show={pullHint} label="Release to go back" />
        <div
          id="rvfax-vehicle-report"
          className="mx-auto w-full max-w-lg space-y-3 px-3 pb-28 pt-3 sm:px-4"
        >
          {/* Top actions */}
          <div
            className="flex flex-wrap items-center justify-between gap-2"
            data-no-export
          >
            <button
              type="button"
              onClick={onBack}
              className="inline-flex items-center gap-1.5 rounded-full border border-white/20 bg-black/40 px-3 py-1.5 text-[12px] font-bold text-white"
            >
              <ArrowLeft className="size-3.5" />
              Back
            </button>
            <div className="flex flex-wrap items-center gap-1.5">
              <button
                type="button"
                onClick={onToggleSave}
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[12px] font-bold",
                  saved
                    ? "border-ruby/50 bg-ruby/25 text-white"
                    : "border-white/20 bg-black/40 text-white",
                )}
              >
                <Heart className={cn("size-3.5", saved && "fill-current")} />
                Save
              </button>
              {shellNav ? (
                <button
                  type="button"
                  onClick={() =>
                    shellNav.openCalWithPrice(
                      market.retailLow,
                      `${year} ${make} ${model}`,
                    )
                  }
                  className="inline-flex items-center gap-1.5 rounded-full border border-gold/40 bg-gold/15 px-3 py-1.5 text-[12px] font-bold text-gold-bright"
                >
                  <Calculator className="size-3.5" />
                  Finance
                </button>
              ) : null}
              <button
                type="button"
                onClick={() => void exportPdf()}
                disabled={exportBusy}
                className="inline-flex items-center gap-1.5 rounded-full border border-white/20 bg-black/40 px-3 py-1.5 text-[12px] font-bold text-white disabled:opacity-50"
              >
                {exportBusy ? (
                  <Loader2 className="size-3.5 animate-spin" />
                ) : (
                  <Printer className="size-3.5" />
                )}
                PDF
              </button>
              <button
                type="button"
                onClick={onAskGrok}
                className="inline-flex items-center gap-1.5 rounded-full border border-blue/40 bg-blue/25 px-3 py-1.5 text-[12px] font-bold text-white"
              >
                <Sparkles className="size-3.5 text-blue" />
                Ask Grok
              </button>
            </div>
          </div>
          {exportMsg ? (
            <p className="text-center text-[11px] text-blue" data-no-export>
              {exportMsg}
            </p>
          ) : null}

          {/* Report header */}
          <section className="glass-prestige rounded-[1.15rem] p-3.5">
            <div className="flex items-start justify-between gap-2">
              <div>
                <div className="flex items-center gap-2">
                  <span className="rounded-md bg-blue px-1.5 py-0.5 text-[9px] font-black tracking-wide text-white">
                    RvFOX
                  </span>
                  <div>
                    <p className="text-[13px] font-bold text-white">
                      Vehicle History Report
                    </p>
                    <p className="text-[9px] font-semibold tracking-[0.14em] text-white/55">
                      KNOW BEFORE YOU BUY
                    </p>
                  </div>
                </div>
                <p className="mt-1 text-[11px] text-white/70">{generatedAt}</p>
              </div>
              <p className="font-mono text-[10px] text-white/55">{reportId}</p>
            </div>

            <div className="mt-3 grid grid-cols-2 gap-2">
              <StatTile
                label="NHTSA recalls"
                value={
                  recallLoading
                    ? "Checking…"
                    : recallCount > 0
                      ? `${recallCount} on record`
                      : "None found"
                }
                warn={!recallLoading && recallCount > 0}
                ok={!recallLoading && recallCount === 0}
              />
              <StatTile
                label="Service schedule"
                value={`${maintenance.length} tasks`}
              />
              <StatTile label="Use / Class" value={displayType} />
              <StatTile
                label="Data source"
                value={
                  liveLoading
                    ? "Catalog · updating…"
                    : live?.live
                      ? `Live Grok · ${live.confidence}`
                      : "Catalog estimate"
                }
                accent={!!live?.live}
              />
            </div>
            <p className="mt-2 text-[11px] leading-relaxed text-white/75">
              Instant catalog report first, then Live Grok refreshes market when
              ready. Brochure powertrain is pinned for known coaches. Always
              confirm door sticker and a PPI.
            </p>
          </section>

          {/* Overview */}
          <section className="glass-prestige rounded-[1.15rem] p-3.5">
            <p className="text-[11px] font-bold tracking-wide text-white/70">
              Vehicle Overview
            </p>
            <div className="mt-2 flex items-start justify-between gap-3">
              <div>
                <p className="text-[13px] font-semibold text-blue">{year}</p>
                <h1 className="text-[22px] font-bold leading-tight text-white">
                  {make} {model}
                </h1>
                {floorplan ? (
                  <p className="mt-0.5 text-[13px] text-white/80">
                    Floorplan: {floorplan}
                  </p>
                ) : null}
                <div className="mt-2 flex flex-wrap gap-1.5">
                  <Chip>{displayType}</Chip>
                  {brochurePinned || powertrainPin ? (
                    <Chip tone="green">Brochure dims pinned</Chip>
                  ) : null}
                  {recallLoading ? (
                    <Chip>Checking recalls…</Chip>
                  ) : recallCount > 0 ? (
                    <Chip tone="ruby">
                      <AlertTriangle className="size-3" /> {recallCount}{" "}
                      Recalls
                    </Chip>
                  ) : (
                    <Chip tone="green">No open recalls</Chip>
                  )}
                </div>
              </div>
              <div className="text-right">
                <p className="text-[28px] font-bold tabular-nums leading-none text-blue">
                  {displayRating.toFixed(1)}
                </p>
                <p className="mt-1 text-[9px] font-bold tracking-wide text-amber">
                  ★★★★☆
                </p>
                <p className="text-[9px] font-bold tracking-wide text-white/60">
                  RVFAX RATING
                </p>
              </div>
            </div>

            <div className="mt-3 grid grid-cols-4 gap-1.5">
              <MiniStat label="LENGTH" value={specs.lengthFt || "—"} />
              <MiniStat label="SLIDEOUTS" value={specs.slideouts || "—"} />
              <MiniStat label="SLEEPS" value={specs.sleeps || "—"} />
              <MiniStat
                label="NHTSA"
                value={
                  recallLoading
                    ? "…"
                    : recallCount > 0
                      ? String(recallCount)
                      : "0"
                }
                warn={recallCount > 0}
              />
            </div>

            {liveLoading ? (
              <p className="mt-3 flex items-center gap-2 text-[12px] text-sky-200/95">
                <Loader2 className="size-3.5 animate-spin" />
                Powertrain from year/floorplan catalog (
                {trustBadgeLabel(powertrainTrust)}) — Live filling market &
                narrative…
              </p>
            ) : null}
            {!liveLoading && isEstimate ? (
              <p className="mt-3 text-[12px] text-amber">
                Powertrain source: {trustBadgeLabel(powertrainTrust)}
                {liveError ? ` · live failed: ${liveError}` : ""}. Soft fields stay
                catalog until Live succeeds.
              </p>
            ) : null}
            {brochure.accuracyNote ? (
              <p className="mt-2 text-[11px] leading-snug text-emerald-200/90">
                {brochure.accuracyNote}
                {year ? ` · report year ${year}` : ""}
              </p>
            ) : null}
            {live?.live ? (
              <p className="mt-3 text-[12px] font-semibold text-emerald-300">
                Live narrative/market applied · conf {live.confidence}
                {" · powertrain source: "}
                {trustBadgeLabel(powertrainTrust)}
                {live.modelUsed ? ` · model ${live.modelUsed}` : ""}
                {powertrainGuard.liveRejectedReasons.length
                  ? " · Live engine rejected (kept year/floorplan catalog)"
                  : ""}
              </p>
            ) : null}
            {live?.live && live.sourcesNote ? (
              <p className="mt-1.5 text-[10px] leading-snug text-white/50">
                Sources: {live.sourcesNote}
              </p>
            ) : null}

            {/* Trust source badges — not "hard locks" */}
            <div className="mt-3 flex flex-wrap gap-1.5">
              {(
                [
                  ["local", "Your correction"],
                  ["pinned", "Year/floorplan pin"],
                  ["catalog", "Year/floorplan catalog"],
                  ["live-validated", "Live (validated)"],
                  ["live-unverified", "Live (unverified)"],
                ] as const
              ).map(([id, label]) => {
                const active = powertrainTrust === id;
                return (
                  <span
                    key={id}
                    className={cn(
                      "rounded-full border px-2 py-0.5 text-[10px] font-semibold tracking-wide",
                      active
                        ? id === "local"
                          ? "border-fuchsia-400/50 bg-fuchsia-500/20 text-fuchsia-100"
                          : id === "pinned"
                          ? "border-gold/50 bg-gold/20 text-gold-bright"
                          : id === "catalog"
                            ? "border-sky-400/45 bg-sky-500/20 text-sky-100"
                            : id === "live-validated"
                              ? "border-emerald-400/45 bg-emerald-500/20 text-emerald-100"
                              : "border-amber-400/45 bg-amber-500/15 text-amber-100"
                        : "border-white/10 bg-white/5 text-white/35",
                    )}
                  >
                    {label}
                    {active ? " · on" : ""}
                  </span>
                );
              })}
              {live?.live ? (
                <span className="rounded-full border border-violet-400/40 bg-violet-500/15 px-2 py-0.5 text-[10px] font-semibold text-violet-100">
                  Narrative · Live
                </span>
              ) : null}
            </div>

            {overviewText ? (
              <p className="mt-2 border-l-2 border-blue/50 pl-3 text-[13.5px] leading-relaxed text-white">
                {overviewText}
              </p>
            ) : null}

            {featureChips.length ? (
              <div className="mt-3 flex flex-wrap gap-1.5">
                {featureChips.map((f) => (
                  <Chip key={f}>{f}</Chip>
                ))}
              </div>
            ) : null}
          </section>

          {/* Confidence banner */}
          <div className="rounded-2xl border border-emerald-400/35 bg-emerald-950/40 px-3.5 py-2.5 text-[11.5px] leading-relaxed text-emerald-100">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span>
                <span className="font-bold tracking-wide text-emerald-200">
                  {liveLoading
                    ? "LIVE GROK · UPDATING"
                    : live?.live
                      ? `LIVE GROK · ${(live.confidence || "—").toUpperCase()}`
                      : "CATALOG · LIVE OPTIONAL"}
                </span>
                {" · "}
                {confNote}
              </span>
              {!liveLoading && !live?.live ? (
                <button
                  type="button"
                  onClick={() => setLiveRetry((n) => n + 1)}
                  className="shrink-0 rounded-full border border-emerald-300/40 bg-emerald-500/20 px-2.5 py-1 text-[10px] font-bold text-emerald-50"
                >
                  Retry live
                </button>
              ) : null}
              <button
                type="button"
                onClick={() => {
                  // Phase 4.3 — bust local verified cache + re-fetch Live
                  refreshCoachDossierCache(year, make, model, floorplan);
                  setLive(null);
                  setLiveError(null);
                  setLiveRetry((n) => n + 1);
                }}
                className="shrink-0 rounded-full border border-white/20 bg-white/10 px-2.5 py-1 text-[10px] font-bold text-white/90"
                title="Clear cached Live data for this coach and fetch fresh"
              >
                Refresh this coach
              </button>
            </div>
          </div>

          {/* Market */}
          <section className="glass-prestige rounded-[1.15rem] p-3.5">
            <div className="mb-2 flex items-center justify-between">
              <p className="text-[10px] font-bold tracking-[0.14em] text-gold">
                ↗ MARKET VALUE
              </p>
              <span
                className={cn(
                  "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-semibold",
                  marketIsLive
                    ? "border-emerald-400/40 bg-emerald-500/15 text-emerald-100"
                    : "border-gold/35 bg-gold/10 text-gold-bright",
                )}
              >
                {liveLoading ? (
                  <>
                    <Loader2 className="size-3 animate-spin" />
                    Catalog · updating
                  </>
                ) : marketIsLive ? (
                  "Live Grok · Market"
                ) : (
                  "Catalog estimate"
                )}
              </span>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <MarketTile
                label="TRADE-IN"
                value={formatMoney(market.tradeIn)}
                sub="Dealer trade"
              />
              <MarketTile
                label="RETAIL LOW"
                value={formatMoney(market.retailLow)}
                sub="Private party"
              />
              <MarketTile
                label="RETAIL HIGH"
                value={formatMoney(market.retailHigh)}
                sub="Dealer asking"
              />
            </div>
            {factors.length ? (
              <ul className="mt-2 space-y-1">
                {factors.map((f) => (
                  <li
                    key={f.label}
                    className={cn(
                      "text-[11px]",
                      f.positive ? "text-emerald-200" : "text-amber",
                    )}
                  >
                    {f.positive ? "↑" : "↓"} {f.label}
                  </li>
                ))}
              </ul>
            ) : null}
          </section>

          {/* Local inventory */}
          <section className="glass-prestige rounded-[1.15rem] p-3.5" data-no-export>
            <div className="mb-2 flex items-center justify-between">
              <p className="text-[10px] font-bold tracking-[0.14em] text-white/70">
                ◎ LOCAL INVENTORY
              </p>
              <span className="text-[10px] text-white/45">
                MarketCheck · dealer listings
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <label className="flex min-w-[7rem] flex-1 items-center gap-1.5 rounded-full border border-white/15 bg-black/30 px-3 py-1.5">
                <MapPin className="size-3.5 text-blue" />
                <input
                  value={invZip}
                  onChange={(e) => setInvZip(e.target.value.replace(/\D/g, "").slice(0, 5))}
                  inputMode="numeric"
                  placeholder="ZIP"
                  className="w-full bg-transparent text-[13px] font-semibold text-white outline-none placeholder:text-white/40"
                />
              </label>
              <select
                value={invRadius}
                onChange={(e) => setInvRadius(Number(e.target.value))}
                className="rounded-full border border-white/15 bg-black/30 px-3 py-1.5 text-[12px] font-semibold text-white"
              >
                <option value={50}>50 mi</option>
                <option value={100}>100 mi</option>
                <option value={250}>250 mi</option>
              </select>
              <button
                type="button"
                onClick={() => void runInventorySearch()}
                disabled={invLoading}
                className="rounded-full border border-blue/40 bg-blue/20 px-3 py-1.5 text-[12px] font-bold text-white disabled:opacity-50"
              >
                {invLoading ? "…" : "Search"}
              </button>
            </div>
            {invError ? (
              <p className="mt-2 text-[11px] text-amber">{invError}</p>
            ) : null}
            {invListings.length ? (
              <ul className="mt-2 space-y-1.5">
                {invListings.slice(0, 5).map((l, i) => (
                  <li
                    key={l.id || i}
                    className="rounded-xl border border-white/10 bg-black/25 px-3 py-2"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="truncate text-[12px] font-bold text-white">
                          {l.heading ||
                            `${l.year || year} ${l.make || make} ${l.model || model}`}
                        </p>
                        <p className="text-[11px] text-white/60">
                          {[l.dealerName, l.city, l.state]
                            .filter(Boolean)
                            .join(" · ") || "Dealer listing"}
                        </p>
                      </div>
                      <p className="shrink-0 text-[13px] font-bold tabular-nums text-gold-bright">
                        {l.price ? formatMoney(l.price) : "—"}
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            ) : invSearched && !invLoading && !invError ? (
              <p className="mt-2 text-[11px] text-white/55">No listings nearby.</p>
            ) : null}
            {invMedian && shellNav ? (
              <button
                type="button"
                onClick={() =>
                  shellNav.openCalWithPrice(
                    invMedian,
                    `${year} ${make} ${model} · local median`,
                  )
                }
                className="mt-2 flex w-full items-center justify-center gap-2 rounded-full border border-gold/40 bg-gold/15 py-2.5 text-[12px] font-bold text-gold-bright"
              >
                <Calculator className="size-3.5" />
                Finance at local median · {formatMoney(invMedian)}
              </button>
            ) : null}
          </section>

          {/* Specs */}
          <Section title="Vehicle Specifications">
            <p className="mb-2 text-[10px] font-bold tracking-[0.12em] text-white/55">
              IDENTITY & DIMENSIONS
            </p>
            <SpecRow label="TYPE" value={displayType} />
            <SpecRow label="YEAR" value={year} />
            <SpecRow label="LENGTH" value={specs.lengthFt} accent />
            <SpecRow label="WIDTH" value={specs.exteriorWidth} />
            <SpecRow label="HEIGHT" value={specs.exteriorHeight} />
            <SpecRow label="CEILING" value={specs.interiorHeight} />
            <SpecRow label="SLIDEOUTS" value={specs.slideouts} />
            <SpecRow label="SLEEPS" value={specs.sleeps} />

            <p className="mb-2 mt-4 flex flex-wrap items-center gap-2 text-[10px] font-bold tracking-[0.12em] text-white/55">
              POWERTRAIN & CHASSIS
              <span
                className={cn(
                  "rounded-full border px-1.5 py-0.5 text-[9px] font-bold tracking-wide",
                  powertrainTrust === "local"
                    ? "border-fuchsia-400/45 bg-fuchsia-500/15 text-fuchsia-100"
                    : powertrainTrust === "pinned"
                      ? "border-gold/45 bg-gold/15 text-gold-bright"
                      : powertrainTrust === "catalog"
                        ? "border-sky-400/40 bg-sky-500/15 text-sky-100"
                        : powertrainTrust === "live-validated"
                          ? "border-emerald-400/40 bg-emerald-500/15 text-emerald-100"
                          : "border-amber-400/40 bg-amber-500/10 text-amber-100",
                )}
              >
                {trustBadgeLabel(powertrainTrust)}
              </span>
            </p>
            <SpecRow label="FUEL" value={displayFuel} />
            <SpecRow label="ENGINE" value={specs.engine} accent />
            <SpecRow label="HORSEPOWER" value={specs.horsepower} accent />
            <SpecRow label="TORQUE" value={specs.torque} />
            <SpecRow label="TRANSMISSION" value={specs.transmission} />
            <SpecRow label="CHASSIS" value={specs.chassis} accent />
            <div className="mt-2 mb-3 flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => {
                  setCorrectEngine(specs.engine || "");
                  setCorrectHp(
                    String(specs.horsepower || "").replace(/[^\d].*$/, "") || "",
                  );
                  setCorrectTorque(
                    String(specs.torque || "").replace(/[^\d].*$/, "") || "",
                  );
                  setCorrectChassis(specs.chassis || "");
                  setCorrectTrans(specs.transmission || "");
                  setCorrectFuel(displayFuel || data.fuelType || "");
                  setCorrectNote("");
                  setCorrectMsg(null);
                  setCorrectOpen(true);
                }}
                className="rounded-full border border-gold/40 bg-gold/15 px-3 py-1.5 text-[11px] font-bold text-gold-bright"
              >
                Correct this spec
              </button>
              {powertrainTrust === "local" ? (
                <button
                  type="button"
                  onClick={() => {
                    const cur = findLocalSpecOverride(
                      year,
                      make,
                      model,
                      floorplan,
                    );
                    if (cur) removeLocalSpecOverride(cur.id);
                    setCorrectBump((n) => n + 1);
                    setCorrectMsg("Local correction removed.");
                  }}
                  className="rounded-full border border-white/20 bg-white/10 px-3 py-1.5 text-[11px] font-bold text-white/85"
                >
                  Clear local correction
                </button>
              ) : null}
              <button
                type="button"
                onClick={() => {
                  const json = exportLocalSpecOverridesJson();
                  const blob = new Blob([json], { type: "application/json" });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement("a");
                  a.href = url;
                  a.download = `rvfax-local-spec-overrides-${year}-${make}-${model}.json`.replace(
                    /\s+/g,
                    "-",
                  );
                  a.click();
                  URL.revokeObjectURL(url);
                  setCorrectMsg("Exported local overrides JSON.");
                }}
                className="rounded-full border border-white/15 bg-white/5 px-3 py-1.5 text-[11px] font-semibold text-white/70"
              >
                Export pins
              </button>
              <button
                type="button"
                disabled={researchBusy}
                onClick={async () => {
                  setResearchBusy(true);
                  setResearchMsg(null);
                  try {
                    const y = parseInt(year, 10) || 2020;
                    const resp = await fetch("/api/rvfax/catalog-research", {
                      method: "POST",
                      headers: {
                        "Content-Type": "application/json",
                        Accept: "application/json",
                      },
                      body: JSON.stringify({
                        make,
                        model,
                        yearFrom: Math.max(2000, y - 4),
                        yearTo: Math.min(2026, y + 2),
                        floorplans: floorplan
                          ? [floorplan]
                          : (data.floorplans || []).slice(0, 8),
                        fuelType: data.fuelType,
                        type: data.type,
                        catalogEngine: brochure.engine,
                        catalogHp: brochure.horsepower,
                      }),
                    });
                    const json = (await resp.json()) as {
                      data?: { patches?: CatalogPowertrainPatch[] };
                      error?: string;
                      meta?: { highOk?: number };
                    };
                    if (!resp.ok) {
                      setResearchMsg(
                        json.error || "AI catalog research failed",
                      );
                      return;
                    }
                    const patches = json.data?.patches || [];
                    for (const p of patches) upsertProposedPatch(p);
                    const high =
                      json.meta?.highOk ??
                      patches.filter(
                        (p) => p.confidence === "high" && p.validation.ok,
                      ).length;
                    setResearchMsg(
                      `AI researched ${patches.length} patch(es) · ${high} high-confidence. Export proposed catalog to review — not auto-written.`,
                    );
                  } catch (e) {
                    setResearchMsg(
                      e instanceof Error ? e.message : "Research failed",
                    );
                  } finally {
                    setResearchBusy(false);
                  }
                }}
                className="rounded-full border border-sky-400/40 bg-sky-500/15 px-3 py-1.5 text-[11px] font-bold text-sky-100 disabled:opacity-50"
              >
                {researchBusy ? "AI researching…" : "AI research catalog"}
              </button>
              <button
                type="button"
                onClick={() => {
                  const json = exportProposedPatchesJson();
                  const blob = new Blob([json], { type: "application/json" });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement("a");
                  a.href = url;
                  a.download = "rvfax-proposed-catalog-patches.json";
                  a.click();
                  URL.revokeObjectURL(url);
                  setResearchMsg("Exported proposed catalog patches JSON.");
                }}
                className="rounded-full border border-white/15 bg-white/5 px-3 py-1.5 text-[11px] font-semibold text-white/70"
              >
                Export AI patches
              </button>
            </div>
            {correctMsg ? (
              <p className="mb-2 text-[11px] text-emerald-200/90">{correctMsg}</p>
            ) : null}
            {researchMsg ? (
              <p className="mb-2 text-[11px] text-sky-200/90">{researchMsg}</p>
            ) : null}
            <SpecRow label="TOW CAPACITY" value={specs.hitchOrPin} />
            <SpecRow label="GENERATOR" value={specs.generator} />
            <SpecRow
              label="HIGHWAY MPG"
              value={
                specs.mpgHighway
                  ? `${specs.mpgHighway}${/est/i.test(specs.mpgHighway) ? "" : " EST."}`
                  : "—"
              }
            />
            <SpecRow label="FUEL CAPACITY" value={specs.fuelCapacity} />

            <p className="mb-2 mt-4 text-[10px] font-bold tracking-[0.12em] text-white/55">
              WEIGHTS & RATING
            </p>
            <SpecRow label="GVWR" value={specs.gvwr} accent />
            <SpecRow label="UVW" value={specs.uvw} />
            <SpecRow label="CCC" value={specs.ccc} />
            <SpecRow label="WARRANTY" value={specs.warranty} />

            <p className="mb-2 mt-4 text-[10px] font-bold tracking-[0.12em] text-white/55">
              TANKS
            </p>
            <SpecRow label="FRESH WATER" value={specs.freshWater} />
            <SpecRow label="GRAY WATER" value={specs.grayWater} />
            <SpecRow label="BLACK WATER" value={specs.blackWater} />
          </Section>

          {floorplansShown.length ? (
            <Section title="Floorplans this year">
              <div className="flex flex-wrap gap-1.5">
                {floorplansShown.map((fp) => (
                  <Chip
                    key={fp}
                    tone={
                      floorplan &&
                      fp.toLowerCase() === floorplan.toLowerCase()
                        ? "blue"
                        : undefined
                    }
                  >
                    {fp}
                  </Chip>
                ))}
              </div>
            </Section>
          ) : null}

          {live?.live &&
          (live.reliabilitySummary ||
            live.commonIssues?.length ||
            live.servicePriorities?.length) ? (
            <Section title="Reliability & ownership">
              {live.reliabilitySummary ? (
                <p className="text-[13px] leading-relaxed text-white/90">
                  {powertrainPin
                    ? sanitizeNarrativeForPin(
                        powertrainPin,
                        live.reliabilitySummary,
                      ) || live.reliabilitySummary
                    : live.reliabilitySummary}
                </p>
              ) : null}
              {live.commonIssues?.length ? (
                <ul className="mt-2 space-y-1.5">
                  {live.commonIssues.map((x) => (
                    <li
                      key={x}
                      className="flex gap-2 text-[12px] text-white/85"
                    >
                      <AlertTriangle className="mt-0.5 size-3.5 shrink-0 text-amber" />
                      {x}
                    </li>
                  ))}
                </ul>
              ) : null}
              {live.servicePriorities?.length ? (
                <ul className="mt-2 space-y-1.5">
                  {live.servicePriorities.map((x) => (
                    <li
                      key={x}
                      className="flex gap-2 text-[12px] text-white/85"
                    >
                      <CheckCircle2 className="mt-0.5 size-3.5 shrink-0 text-emerald-300" />
                      {x}
                    </li>
                  ))}
                </ul>
              ) : null}
              {live.ownerSentiment ? (
                <p className="mt-2 text-[12px] italic text-white/70">
                  {live.ownerSentiment}
                </p>
              ) : null}
            </Section>
          ) : null}

          <Section title="NHTSA safety">
            {recallLoading ? (
              <p className="flex items-center gap-2 text-[13px] text-white/70">
                <Loader2 className="size-4 animate-spin" /> Loading recalls
                from NHTSA…
              </p>
            ) : recallError ? (
              <p className="text-[12px] text-amber">{recallError}</p>
            ) : liveRecalls.length === 0 ? (
              <div className="space-y-2">
                <p className="text-[13px] text-emerald-200">
                  No campaigns matched after exact + broader manufacturer
                  search for this year/make/model.
                </p>
                {recallSearchNote ? (
                  <p className="text-[11px] leading-relaxed text-white/60">
                    {recallSearchNote}
                  </p>
                ) : null}
                <a
                  href="https://www.nhtsa.gov/recalls"
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 text-[11px] font-semibold text-blue"
                >
                  Search nhtsa.gov <ExternalLink className="size-3" />
                </a>
              </div>
            ) : (
              <div className="space-y-2">
                <p className="text-[12px] font-semibold text-ruby">
                  {liveRecalls.length} NHTSA campaign
                  {liveRecalls.length === 1 ? "" : "s"} on record
                </p>
                {recallSearchNote ? (
                  <p className="text-[11px] text-white/55">{recallSearchNote}</p>
                ) : null}
                <ul className="space-y-2">
                  {liveRecalls.map((r, i) => (
                    <li
                      key={`${r.campaignNumber || i}-${i}`}
                      className="rounded-xl border border-ruby/30 bg-ruby/10 px-3 py-2"
                    >
                      <p className="text-[12px] font-bold text-white">
                        {r.component || "Recall"}
                      </p>
                      <p className="mt-0.5 text-[11px] leading-snug text-white/80">
                        {r.summary ||
                          r.consequence ||
                          "See NHTSA for details."}
                      </p>
                      {r.campaignNumber ? (
                        <p className="mt-1 font-mono text-[10px] text-white/55">
                          Campaign {r.campaignNumber}
                        </p>
                      ) : null}
                      {r.remedy ? (
                        <p className="mt-1 text-[10px] text-emerald-200/90">
                          Remedy: {r.remedy}
                        </p>
                      ) : null}
                    </li>
                  ))}
                </ul>
                <a
                  href="https://www.nhtsa.gov/recalls"
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 text-[11px] font-semibold text-blue"
                >
                  Verify on nhtsa.gov <ExternalLink className="size-3" />
                </a>
              </div>
            )}

            {liveDefects.length > 0 ? (
              <div className="mt-3">
                <p className="mb-1.5 text-[10px] font-bold tracking-wide text-white/55">
                  OWNER COMPLAINTS (sample)
                </p>
                <ul className="space-y-1.5">
                  {liveDefects.slice(0, 8).map((d, i) => (
                    <li
                      key={i}
                      className="rounded-lg border border-white/10 bg-black/25 px-2.5 py-1.5 text-[11px] text-white/80"
                    >
                      <span className="font-semibold text-white">
                        {d.component || "Complaint"}
                      </span>
                      {d.summary ? ` — ${d.summary}` : null}
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}
          </Section>

          {maintenance.length ? (
            <section className="glass-prestige rounded-[1.15rem] p-3.5">
              <button
                type="button"
                onClick={() => setOpenMaint((v) => !v)}
                className="flex w-full items-center justify-between"
              >
                <span className="flex items-center gap-1.5 text-[11px] font-bold tracking-[0.12em] text-white">
                  <FileText className="size-3.5 text-amber" />
                  MAINTENANCE SCHEDULE ({maintenance.length})
                </span>
                <span className="text-[11px] text-white/60">
                  {openMaint ? "Hide" : "Show"}
                </span>
              </button>
              {openMaint ? (
                <ul className="mt-2 space-y-2">
                  {maintenance.map((m, i) => (
                    <li
                      key={i}
                      className="rounded-xl border border-white/10 bg-black/30 px-3 py-2"
                    >
                      <p className="text-[13px] font-bold text-white">
                        {m.task}
                      </p>
                      <p className="mt-0.5 text-[11px] text-white/75">
                        {m.interval} · {m.category} · {m.priority}
                      </p>
                    </li>
                  ))}
                </ul>
              ) : null}
            </section>
          ) : null}

          <p className="flex gap-1.5 px-1 pb-4 text-[10px] leading-relaxed text-white/65">
            <Info className="mt-0.5 size-3 shrink-0" />
            Brochure-pinned powertrain where verified; Live Grok for market &
            ownership notes; NHTSA via official API. Always verify brochure, door
            sticker, and nhtsa.gov before purchase. Use Correct this spec to save
            a local exportable pin.
          </p>
        </div>
      </div>

      {correctOpen ? (
        <div
          className="fixed inset-0 z-[80] flex items-end justify-center bg-black/65 p-3 sm:items-center"
          role="dialog"
          aria-modal="true"
          aria-label="Correct powertrain specs"
        >
          <div className="max-h-[90vh] w-full max-w-md overflow-y-auto rounded-2xl border border-white/15 bg-[#0c1220] p-4 shadow-2xl">
            <div className="mb-3 flex items-start justify-between gap-2">
              <div>
                <p className="text-[11px] font-bold tracking-[0.14em] text-gold">
                  CORRECT THIS SPEC
                </p>
                <p className="mt-0.5 text-[13px] font-semibold text-white">
                  {year} {make} {model}
                  {floorplan ? ` · ${floorplan}` : ""}
                </p>
                <p className="mt-1 text-[11px] text-white/55">
                  Saves a local override on this device. Export pins to share
                  with ops or pin into the catalog later.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setCorrectOpen(false)}
                className="rounded-full border border-white/15 px-2.5 py-1 text-[11px] text-white/70"
              >
                Close
              </button>
            </div>
            <div className="space-y-2.5">
              {(
                [
                  ["Engine", correctEngine, setCorrectEngine],
                  ["Horsepower", correctHp, setCorrectHp],
                  ["Torque (lb-ft)", correctTorque, setCorrectTorque],
                  ["Chassis", correctChassis, setCorrectChassis],
                  ["Transmission", correctTrans, setCorrectTrans],
                  ["Fuel", correctFuel, setCorrectFuel],
                  ["Note", correctNote, setCorrectNote],
                ] as const
              ).map(([label, val, setVal]) => (
                <label key={label} className="block">
                  <span className="text-[10px] font-bold tracking-wide text-white/50">
                    {label}
                  </span>
                  <input
                    value={val}
                    onChange={(e) => setVal(e.target.value)}
                    className="mt-0.5 w-full rounded-xl border border-white/15 bg-black/40 px-3 py-2 text-[13px] text-white outline-none focus:border-gold/50"
                    inputMode={
                      label === "Horsepower" || label.startsWith("Torque")
                        ? "numeric"
                        : "text"
                    }
                  />
                </label>
              ))}
            </div>
            <div className="mt-4 flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => {
                  const hp = parseInt(correctHp.replace(/[^\d]/g, ""), 10);
                  const tq = parseInt(correctTorque.replace(/[^\d]/g, ""), 10);
                  saveLocalSpecOverride({
                    year,
                    make,
                    model,
                    floorplan: floorplan || "",
                    engine: correctEngine || undefined,
                    horsepower: Number.isFinite(hp) && hp > 0 ? hp : undefined,
                    torqueLbFt: Number.isFinite(tq) && tq > 0 ? tq : undefined,
                    chassis: correctChassis || undefined,
                    transmission: correctTrans || undefined,
                    fuelType: correctFuel || undefined,
                    note: correctNote || "User correction from report",
                  });
                  setCorrectBump((n) => n + 1);
                  setCorrectOpen(false);
                  setCorrectMsg("Local correction saved · exportable pin.");
                }}
                className="flex-1 rounded-full border border-gold/45 bg-gold/20 py-2.5 text-[13px] font-bold text-gold-bright"
              >
                Save correction
              </button>
              <button
                type="button"
                onClick={() => setCorrectOpen(false)}
                className="rounded-full border border-white/20 px-4 py-2.5 text-[13px] font-semibold text-white/80"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function Section({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section className="glass-prestige rounded-[1.15rem] p-3.5">
      <h2 className="mb-3 text-[15px] font-bold text-white">{title}</h2>
      {children}
    </section>
  );
}

function SpecRow({
  label,
  value,
  accent,
}: {
  label: string;
  value?: string | null;
  accent?: boolean;
}) {
  return (
    <div className="flex items-baseline justify-between gap-3 border-b border-white/8 py-1.5 last:border-0">
      <span className="text-[11px] font-bold tracking-wide text-blue/90">
        {label}
      </span>
      <span
        className={cn(
          "max-w-[58%] text-right text-[13px] font-semibold tabular-nums",
          accent ? "text-white" : "text-white",
        )}
      >
        {value && String(value).trim() ? value : "—"}
      </span>
    </div>
  );
}

function Chip({
  children,
  tone,
}: {
  children: React.ReactNode;
  tone?: "ruby" | "green" | "blue";
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-semibold",
        tone === "ruby"
          ? "border-ruby/40 bg-ruby/20 text-white"
          : tone === "green"
            ? "border-emerald-400/40 bg-emerald-500/15 text-emerald-100"
            : tone === "blue"
              ? "border-blue/40 bg-blue/20 text-white"
              : "border-white/20 bg-black/40 text-white",
      )}
    >
      {children}
    </span>
  );
}

function MarketTile({
  label,
  value,
  sub,
}: {
  label: string;
  value: string;
  sub: string;
}) {
  return (
    <div className="rounded-xl border border-white/12 bg-black/30 px-2 py-2 text-center">
      <p className="text-[9px] font-bold tracking-wide text-white/70">{label}</p>
      <p className="mt-0.5 text-[13px] font-bold tabular-nums text-white">
        {value}
      </p>
      <p className="text-[9px] text-white/55">{sub}</p>
    </div>
  );
}

function StatTile({
  label,
  value,
  warn,
  ok,
  accent,
}: {
  label: string;
  value: string;
  warn?: boolean;
  ok?: boolean;
  accent?: boolean;
}) {
  return (
    <div
      className={cn(
        "rounded-xl border px-2.5 py-2",
        warn
          ? "border-amber/40 bg-amber/10"
          : ok
            ? "border-emerald-400/30 bg-emerald-500/10"
            : accent
              ? "border-blue/35 bg-blue/10"
              : "border-white/12 bg-black/25",
      )}
    >
      <p className="text-[9px] font-bold tracking-wide text-white/60">{label}</p>
      <p className="mt-0.5 text-[12px] font-bold text-white">{value}</p>
    </div>
  );
}

function MiniStat({
  label,
  value,
  warn,
}: {
  label: string;
  value: string;
  warn?: boolean;
}) {
  return (
    <div className="rounded-xl border border-white/12 bg-black/30 px-1.5 py-2 text-center">
      <p
        className={cn(
          "text-[12px] font-bold tabular-nums",
          warn ? "text-amber" : "text-white",
        )}
      >
        {value}
      </p>
      <p className="mt-0.5 text-[8px] font-bold tracking-wide text-white/55">
        {label}
      </p>
    </div>
  );
}
