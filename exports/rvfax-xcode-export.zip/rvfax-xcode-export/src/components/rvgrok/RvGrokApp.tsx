import { useCallback, useEffect, useRef, useState } from "react";
import {
  Camera,
  History,
  Loader2,
  Mic,
  Plus,
  Radio,
  Send,
  Sparkles,
  Square,
  Volume2,
  X,
} from "lucide-react";
import type { AgentStep, ChatSession, Message } from "@/lib/rvgrok/types";
import { AGENT_MODE_KEY } from "@/lib/rvgrok/types";
import {
  deleteSession,
  loadSessions,
  upsertSession,
} from "@/lib/rvgrok/history";
import { streamChat } from "@/lib/rvgrok/stream";
import { GrokRealtimeSession } from "@/lib/rvgrok/realtime";
import type { RealtimeStatus } from "@/lib/rvgrok/realtime";
import type { GrokVoice } from "@/lib/rvgrok/voice";
import {
  DEFAULT_VOICE,
  LIVE_VOICE_KEY,
  VOICE_MODE_KEY,
  VOICE_SPEED_KEY,
  VOICE_STORAGE_KEY,
  createPushToTalkRecognition,
  getSpeechRecognitionCtor,
  speakWithBrowserTts,
  stopBrowserTts,
} from "@/lib/rvgrok/voice";
import {
  buildUserContent,
  compressImageToDataUrl,
} from "@/lib/rvgrok/vision";
import { cn, uid } from "@/lib/utils";
import { MessageBubble } from "./MessageBubble";
import { HistoryPanel } from "./HistoryPanel";
import { VoicePanel } from "./VoicePanel";
import { useKeyboardInset } from "@/lib/hooks/useKeyboardInset";
import { usePullToReset } from "@/lib/hooks/usePullToReset";
import { PullResetHint } from "@/components/shell/PullResetHint";
import { ScrollSuiteHeader } from "@/components/shell/ScrollChrome";
import { SuiteBackdrop } from "@/components/shell/SuitePage";

export function RvGrokApp({
  seedPrompt,
  onSeedConsumed,
  active: _active = true,
  onNavigate: _onNavigate,
  onSplashPlayingChange: _onSplashPlayingChange,
}: {
  seedPrompt?: string;
  onSeedConsumed?: () => void;
  active?: boolean;
  onNavigate?: (tab: import("@/components/shell/BottomTabs").AppTab) => void;
  onSplashPlayingChange?: (playing: boolean) => void;
} = {}) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [agentMode, setAgentMode] = useState(false);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [voicePanelOpen, setVoicePanelOpen] = useState(false);
  const [activeModel, setActiveModel] = useState<string | null>(null);

  const [selectedVoice, setSelectedVoice] = useState(DEFAULT_VOICE);
  const [voiceMode, setVoiceMode] = useState(false);
  const [liveVoice, setLiveVoice] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [isRecording, setIsRecording] = useState(false);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [previewingId, setPreviewingId] = useState<string | null>(null);
  const [realtimeStatus, setRealtimeStatus] = useState<RealtimeStatus>("idle");
  const [realtimeDetail, setRealtimeDetail] = useState<string | null>(null);
  const [interimTranscript, setInterimTranscript] = useState("");
  const [voiceError, setVoiceError] = useState<string | null>(null);
  const [reconnectAttempt, setReconnectAttempt] = useState(0);
  const [pendingImage, setPendingImage] = useState<string | null>(null);
  const [imageBusy, setImageBusy] = useState(false);

  const listRef = useRef<HTMLDivElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const kb = useKeyboardInset();
  const abortRef = useRef<AbortController | null>(null);
  const recognitionRef = useRef<ReturnType<
    typeof createPushToTalkRecognition
  > | null>(null);
  const finalTranscriptRef = useRef("");
  const realtimeRef = useRef<GrokRealtimeSession | null>(null);
  const liveUserMsgId = useRef<string | null>(null);
  const liveAsstMsgId = useRef<string | null>(null);
  const voiceModeRef = useRef(voiceMode);
  const liveVoiceRef = useRef(liveVoice);
  const sessionsRef = useRef(sessions);
  const sessionIdRef = useRef(sessionId);
  const startingLiveRef = useRef(false);
  const continuousLoopRef = useRef(false);
  const skipNextAutoRecordRef = useRef(false);
  const sendMessageRef = useRef<
    (text?: string, opts?: { fromVoice?: boolean }) => Promise<void>
  >(async () => {});
  const startLiveSessionRef = useRef<() => Promise<void>>(async () => {});
  const startPushToTalkRef = useRef<() => void>(() => {});

  useEffect(() => {
    return () => {
      stopBrowserTts();
      recognitionRef.current?.abort();
      realtimeRef.current?.stop();
    };
  }, []);

  useEffect(() => {
    try {
      if (localStorage.getItem(AGENT_MODE_KEY) === "true") setAgentMode(true);
      const v = localStorage.getItem(VOICE_STORAGE_KEY);
      if (v) setSelectedVoice(v);
      const sp = localStorage.getItem(VOICE_SPEED_KEY);
      if (sp) {
        const n = Number(sp);
        if (Number.isFinite(n) && n > 0) setPlaybackSpeed(n);
      }
      if (localStorage.getItem(VOICE_MODE_KEY) === "true") setVoiceMode(true);
      if (localStorage.getItem(LIVE_VOICE_KEY) === "true") {
        setLiveVoice(true);
        liveVoiceRef.current = true;
      }
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    setSessions(loadSessions());
  }, []);

  const scrollToBottom = useCallback(() => {
    requestAnimationFrame(() => {
      const el = listRef.current;
      if (el) el.scrollTop = el.scrollHeight;
    });
  }, []);

  const toggleAgentMode = () => {
    setAgentMode((v) => {
      const next = !v;
      try {
        localStorage.setItem(AGENT_MODE_KEY, String(next));
      } catch {
        /* ignore */
      }
      return next;
    });
  };

  const persistVoice = (id: string) => {
    setSelectedVoice(id);
    try {
      localStorage.setItem(VOICE_STORAGE_KEY, id);
    } catch {
      /* ignore */
    }
  };

  const persistSpeed = (s: number) => {
    setPlaybackSpeed(s);
    try {
      localStorage.setItem(VOICE_SPEED_KEY, String(s));
    } catch {
      /* ignore */
    }
  };

  const stopLiveSession = useCallback((opts?: { disarm?: boolean }) => {
    startingLiveRef.current = false;
    realtimeRef.current?.stop();
    realtimeRef.current = null;
    setRealtimeStatus("idle");
    setRealtimeDetail(null);
    liveUserMsgId.current = null;
    liveAsstMsgId.current = null;
    if (opts?.disarm) {
      liveVoiceRef.current = false;
      setLiveVoice(false);
      try {
        localStorage.setItem(LIVE_VOICE_KEY, "false");
      } catch {
        /* ignore */
      }
    }
  }, []);

  const startNewChat = useCallback(() => {
    abortRef.current?.abort();
    recognitionRef.current?.abort();
    realtimeRef.current?.stop();
    realtimeRef.current = null;
    startingLiveRef.current = false;
    stopBrowserTts();
    setMessages([]);
    setSessionId(null);
    setInput("");
    setPendingImage(null);
    setIsLoading(false);
    setIsRecording(false);
    setSpeakingId(null);
    setActiveModel(null);
    setRealtimeStatus("idle");
    setRealtimeDetail(null);
    setInterimTranscript("");
    setVoiceError(null);
  }, []);

  const pullHint = usePullToReset(listRef, startNewChat);

  const handleStop = () => {
    abortRef.current?.abort();
    abortRef.current = null;
    recognitionRef.current?.abort();
    recognitionRef.current = null;
    continuousLoopRef.current = false;
    skipNextAutoRecordRef.current = true;
    stopLiveSession({ disarm: true });
    stopBrowserTts();
    setIsLoading(false);
    setIsRecording(false);
    setSpeakingId(null);
    setInterimTranscript("");
    setVoiceMode(false);
    voiceModeRef.current = false;
    try {
      localStorage.setItem(VOICE_MODE_KEY, "false");
    } catch {
      /* ignore */
    }
    setMessages((prev) =>
      prev.map((m) =>
        m.streaming
          ? { ...m, streaming: false, content: m.content || "Cancelled." }
          : m,
      ),
    );
  };

  const handleSpeak = useCallback(
    (msgId: string, text: string) => {
      if (speakingId === msgId) {
        stopBrowserTts();
        setSpeakingId(null);
        return;
      }
      stopBrowserTts();
      setSpeakingId(msgId);
      speakWithBrowserTts(text, {
        rate: playbackSpeed,
        onEnd: () => setSpeakingId(null),
      });
    },
    [speakingId, playbackSpeed],
  );

  const handlePreviewVoice = useCallback(
    (voice: GrokVoice) => {
      if (previewingId === voice.id) {
        stopBrowserTts();
        setPreviewingId(null);
        return;
      }
      stopBrowserTts();
      setPreviewingId(voice.id);
      speakWithBrowserTts(
        `Hi, I am ${voice.name}. Your RvGrok voice for RV intelligence.`,
        {
          rate: playbackSpeed,
          onEnd: () => setPreviewingId(null),
        },
      );
    },
    [previewingId, playbackSpeed],
  );

  const onPickImage = useCallback(async (file: File | null) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setVoiceError("Please choose a photo (JPEG or PNG).");
      return;
    }
    setImageBusy(true);
    setVoiceError(null);
    try {
      const dataUrl = await compressImageToDataUrl(file);
      setPendingImage(dataUrl);
    } catch (e) {
      setVoiceError(
        e instanceof Error ? e.message : "Could not process that photo",
      );
    } finally {
      setImageBusy(false);
      if (cameraInputRef.current) cameraInputRef.current.value = "";
    }
  }, []);

  const sendMessage = useCallback(
    async (text?: string, opts?: { fromVoice?: boolean }) => {
      const messageText = (text ?? input).trim();
      const image = pendingImage;
      if ((!messageText && !image) || isLoading) return;
      setInput("");
      setPendingImage(null);
      setInterimTranscript("");
      setVoiceError(null);

      const userMsg: Message = {
        id: uid("u"),
        role: "user",
        content: messageText || (image ? "Analyze this RV photo" : ""),
        timestamp: new Date(),
        imageDataUrl: image || undefined,
      };
      const assistantMsgId = uid("a");
      const assistantMsg: Message = {
        id: assistantMsgId,
        role: "assistant",
        content: "",
        streaming: true,
        timestamp: new Date(),
        isAgentMode: agentMode,
        agentSteps: [],
      };

      setMessages((prev) => [...prev, userMsg, assistantMsg]);
      setIsLoading(true);
      scrollToBottom();

      const controller = new AbortController();
      abortRef.current = controller;

      let fullContent = "";
      const liveSteps: AgentStep[] = [];

      try {
        const history = [...messages, userMsg].slice(-10).map((m) => ({
          role: m.role,
          content:
            m.role === "user" && m.imageDataUrl
              ? buildUserContent(m.content, m.imageDataUrl)
              : m.content,
        }));

        await streamChat({
          messages: history,
          agentMode,
          signal: controller.signal,
          handlers: {
            onModel: (m) => setActiveModel(m),
            onStep: (step) => {
              const idx = liveSteps.findIndex((s) => s.step === step.step);
              if (idx >= 0) liveSteps[idx] = step;
              else liveSteps.push(step);
              setMessages((prev) =>
                prev.map((m) =>
                  m.id === assistantMsgId
                    ? { ...m, agentSteps: [...liveSteps], streaming: true }
                    : m,
                ),
              );
              scrollToBottom();
            },
            onDelta: (delta) => {
              fullContent += delta;
              setMessages((prev) =>
                prev.map((m) =>
                  m.id === assistantMsgId
                    ? {
                        ...m,
                        content: fullContent,
                        agentSteps: [...liveSteps],
                        streaming: true,
                      }
                    : m,
                ),
              );
              scrollToBottom();
            },
            onError: (msg) => {
              fullContent = fullContent || `Error: ${msg}`;
            },
          },
        });

        if (agentMode) setActiveModel((m) => m || "grok-4.5 · Agent");

        const finalContent =
          fullContent ||
          (agentMode
            ? "Agent completed research. No summary generated."
            : "Unable to generate a response. Please try again.");

        setMessages((prev) => {
          const updated = prev.map((m) =>
            m.id === assistantMsgId
              ? {
                  ...m,
                  content: finalContent,
                  streaming: false,
                  isAgentMode: agentMode,
                  agentSteps: [...liveSteps],
                }
              : m,
          );
          const { sessions: next, id } = upsertSession(
            sessionsRef.current,
            updated,
            sessionIdRef.current,
          );
          sessionsRef.current = next;
          setSessions(next);
          if (id !== sessionIdRef.current) {
            sessionIdRef.current = id;
            setSessionId(id);
          }
          return updated;
        });

        const shouldSpeak =
          (voiceModeRef.current || opts?.fromVoice) &&
          !liveVoiceRef.current &&
          finalContent &&
          !controller.signal.aborted;

        if (shouldSpeak) {
          setSpeakingId(assistantMsgId);
          speakWithBrowserTts(finalContent, {
            rate: playbackSpeed,
            onEnd: () => {
              setSpeakingId(null);
              if (
                continuousLoopRef.current &&
                !skipNextAutoRecordRef.current &&
                !liveVoiceRef.current
              ) {
                window.setTimeout(() => startPushToTalkRef.current(), 280);
              }
              skipNextAutoRecordRef.current = false;
            },
          });
        } else if (
          continuousLoopRef.current &&
          opts?.fromVoice &&
          !liveVoiceRef.current &&
          !controller.signal.aborted
        ) {
          window.setTimeout(() => startPushToTalkRef.current(), 400);
        }
      } catch (err: unknown) {
        if ((err as Error)?.name === "AbortError") return;
        const msg =
          err instanceof Error ? err.message : "Failed to connect";
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantMsgId
              ? {
                  ...m,
                  content: `Error: ${msg}. Please try again.`,
                  streaming: false,
                }
              : m,
          ),
        );
      } finally {
        abortRef.current = null;
        setIsLoading(false);
        scrollToBottom();
      }
    },
    [
      input,
      pendingImage,
      isLoading,
      messages,
      agentMode,
      scrollToBottom,
      playbackSpeed,
    ],
  );

  useEffect(() => {
    sendMessageRef.current = sendMessage;
  }, [sendMessage]);

  const startPushToTalk = useCallback(() => {
    if (liveVoiceRef.current) return;
    if (!getSpeechRecognitionCtor()) {
      setVoiceError(
        "Speech recognition not supported here. Tap the mic for Live Grok Voice instead.",
      );
      return;
    }
    if (recognitionRef.current) {
      try {
        recognitionRef.current.abort();
      } catch {
        /* ignore */
      }
      recognitionRef.current = null;
    }

    stopBrowserTts();
    setSpeakingId(null);
    setVoiceError(null);
    finalTranscriptRef.current = "";
    setInterimTranscript("");
    skipNextAutoRecordRef.current = false;

    const rec = createPushToTalkRecognition({
      onInterim: (t) => setInterimTranscript(t),
      onFinal: (t) => {
        finalTranscriptRef.current = (
          finalTranscriptRef.current +
          " " +
          t
        ).trim();
        setInterimTranscript("");
        setInput(finalTranscriptRef.current);
      },
      onError: (err) => {
        if (err !== "aborted" && err !== "no-speech") {
          setVoiceError(`Mic: ${err}`);
        }
        setIsRecording(false);
        if (
          continuousLoopRef.current &&
          (err === "no-speech" || err === "aborted")
        ) {
          window.setTimeout(() => {
            if (continuousLoopRef.current && !liveVoiceRef.current) {
              startPushToTalkRef.current();
            }
          }, 500);
        }
      },
      onEnd: () => {
        setIsRecording(false);
        const spoken = finalTranscriptRef.current.trim();
        finalTranscriptRef.current = "";
        setInterimTranscript("");
        if (spoken) {
          void sendMessageRef.current(spoken, { fromVoice: true });
        } else if (continuousLoopRef.current && !liveVoiceRef.current) {
          window.setTimeout(() => {
            if (continuousLoopRef.current && !liveVoiceRef.current) {
              startPushToTalkRef.current();
            }
          }, 450);
        }
      },
    });
    if (!rec) return;
    recognitionRef.current = rec;
    try {
      rec.start();
      setIsRecording(true);
    } catch (e) {
      setVoiceError(
        e instanceof Error ? e.message : "Could not start microphone",
      );
    }
  }, []);

  useEffect(() => {
    startPushToTalkRef.current = startPushToTalk;
  }, [startPushToTalk]);

  const stopPushToTalk = useCallback((opts?: { send?: boolean }) => {
    const shouldSend = opts?.send !== false;
    try {
      recognitionRef.current?.stop();
    } catch {
      /* ignore */
    }
    recognitionRef.current = null;
    setIsRecording(false);
    const spoken = finalTranscriptRef.current.trim();
    finalTranscriptRef.current = "";
    setInterimTranscript("");
    if (shouldSend && spoken) {
      void sendMessageRef.current(spoken, { fromVoice: true });
    }
  }, []);

  const startLiveSession = useCallback(async () => {
    if (startingLiveRef.current) return;
    if (realtimeRef.current?.isActive) return;

    try {
      recognitionRef.current?.abort();
    } catch {
      /* ignore */
    }
    recognitionRef.current = null;
    setIsRecording(false);

    startingLiveRef.current = true;
    stopBrowserTts();
    setSpeakingId(null);
    setVoiceError(null);
    setRealtimeStatus("connecting");
    setRealtimeDetail("Starting Live Voice…");

    realtimeRef.current?.stop();
    realtimeRef.current = null;

    const session = new GrokRealtimeSession(
      {
        onStatus: (s, detail) => {
          setRealtimeStatus(s);
          setRealtimeDetail(detail ?? null);
        },
        onUserTranscript: (text) => {
          const uidMsg = liveUserMsgId.current;
          if (uidMsg) {
            setMessages((prev) =>
              prev.map((m) =>
                m.id === uidMsg ? { ...m, content: text } : m,
              ),
            );
          } else {
            const id = uid("u-live");
            liveUserMsgId.current = id;
            setMessages((prev) => [
              ...prev,
              {
                id,
                role: "user",
                content: text,
                timestamp: new Date(),
              },
            ]);
          }
          scrollToBottom();
        },
        onAssistantDelta: (text) => {
          let asstId = liveAsstMsgId.current;
          if (!asstId) {
            asstId = uid("a-live");
            liveAsstMsgId.current = asstId;
            if (!liveUserMsgId.current) {
              const uId = uid("u-live");
              liveUserMsgId.current = uId;
              setMessages((prev) => [
                ...prev,
                {
                  id: uId,
                  role: "user",
                  content: "🎤 Listening…",
                  timestamp: new Date(),
                },
                {
                  id: asstId!,
                  role: "assistant",
                  content: text,
                  streaming: true,
                  timestamp: new Date(),
                },
              ]);
            } else {
              setMessages((prev) => [
                ...prev,
                {
                  id: asstId!,
                  role: "assistant",
                  content: text,
                  streaming: true,
                  timestamp: new Date(),
                },
              ]);
            }
          } else {
            setMessages((prev) =>
              prev.map((m) =>
                m.id === asstId
                  ? { ...m, content: text, streaming: true }
                  : m,
              ),
            );
          }
          scrollToBottom();
        },
        onAssistantDone: (text) => {
          const asstId = liveAsstMsgId.current;
          if (asstId) {
            setMessages((prev) => {
              const updated = prev.map((m) =>
                m.id === asstId
                  ? { ...m, content: text, streaming: false }
                  : m,
              );
              const { sessions: next, id } = upsertSession(
                sessionsRef.current,
                updated,
                sessionIdRef.current,
              );
              sessionsRef.current = next;
              setSessions(next);
              if (id !== sessionIdRef.current) {
                sessionIdRef.current = id;
                setSessionId(id);
              }
              return updated;
            });
          }
          liveUserMsgId.current = null;
          liveAsstMsgId.current = null;
          scrollToBottom();
        },
        onError: (message) => {
          setVoiceError(message);
          setRealtimeDetail(message);
        },
        onDisconnected: (reason) => {
          realtimeRef.current = null;
          startingLiveRef.current = false;
          if (liveVoiceRef.current) {
            setRealtimeDetail("Reconnecting…");
            setReconnectAttempt((n) => n + 1);
            window.setTimeout(() => {
              if (liveVoiceRef.current) {
                void startLiveSessionRef.current();
              }
            }, 900);
          } else {
            setRealtimeStatus("idle");
            setVoiceError(`Disconnected: ${reason}`);
          }
        },
      },
      selectedVoice,
    );

    realtimeRef.current = session;
    try {
      await session.start();
      setReconnectAttempt(0);
    } catch (e) {
      const msg =
        e instanceof Error ? e.message : "Could not start Live Voice";
      setVoiceError(msg);
      setRealtimeStatus("error");
      setRealtimeDetail(msg);
      realtimeRef.current = null;
      if (liveVoiceRef.current && reconnectAttempt < 2) {
        window.setTimeout(() => {
          if (liveVoiceRef.current) void startLiveSessionRef.current();
        }, 1200);
      }
    } finally {
      startingLiveRef.current = false;
    }
  }, [selectedVoice, scrollToBottom, reconnectAttempt]);

  useEffect(() => {
    startLiveSessionRef.current = startLiveSession;
  }, [startLiveSession]);

  const setLiveVoiceArmed = useCallback(
    (on: boolean) => {
      liveVoiceRef.current = on;
      setLiveVoice(on);
      try {
        localStorage.setItem(LIVE_VOICE_KEY, String(on));
      } catch {
        /* ignore */
      }

      if (on) {
        continuousLoopRef.current = false;
        try {
          recognitionRef.current?.abort();
        } catch {
          /* ignore */
        }
        recognitionRef.current = null;
        setIsRecording(false);
        setVoicePanelOpen(false);
        void startLiveSessionRef.current();
      } else {
        stopLiveSession();
        if (voiceModeRef.current) {
          continuousLoopRef.current = true;
          window.setTimeout(() => startPushToTalkRef.current(), 300);
        }
      }
    },
    [stopLiveSession],
  );

  const setVoiceModeArmed = useCallback((on: boolean) => {
    voiceModeRef.current = on;
    setVoiceMode(on);
    try {
      localStorage.setItem(VOICE_MODE_KEY, String(on));
    } catch {
      /* ignore */
    }

    continuousLoopRef.current = on && !liveVoiceRef.current;

    if (on && !liveVoiceRef.current) {
      setVoicePanelOpen(false);
      window.setTimeout(() => startPushToTalkRef.current(), 200);
    } else if (!on && !liveVoiceRef.current) {
      skipNextAutoRecordRef.current = true;
      try {
        recognitionRef.current?.abort();
      } catch {
        /* ignore */
      }
      recognitionRef.current = null;
      setIsRecording(false);
      stopBrowserTts();
      setSpeakingId(null);
    }
  }, []);

  /**
   * Mic button = Live Grok Voice.
   * Tap → start continuous live session; tap again → stop.
   * (Push-to-talk "Voice Mode" stays available from Settings.)
   */
  const handleMicPress = () => {
    const isLive =
      realtimeStatus === "connecting" ||
      realtimeStatus === "listening" ||
      realtimeStatus === "thinking" ||
      realtimeStatus === "speaking";

    if (isLive || realtimeRef.current) {
      stopLiveSession({ disarm: true });
      return;
    }

    if (isRecording) {
      stopPushToTalk({ send: false });
    }

    // Always activate Live Voice from the mic
    setLiveVoiceArmed(true);
  };

  const onKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      void sendMessage();
    }
  };

  useEffect(() => {
    if (!seedPrompt?.trim()) return;
    const t = seedPrompt.trim();
    onSeedConsumed?.();
    void sendMessageRef.current(t);
  }, [seedPrompt, onSeedConsumed]);

  useEffect(() => {
    sessionsRef.current = sessions;
  }, [sessions]);
  useEffect(() => {
    sessionIdRef.current = sessionId;
  }, [sessionId]);
  useEffect(() => {
    voiceModeRef.current = voiceMode;
  }, [voiceMode]);
  useEffect(() => {
    liveVoiceRef.current = liveVoice;
  }, [liveVoice]);

  const modelLabel = activeModel
    ? activeModel.replace(/grok-/gi, "Grok ").replace(/grok /gi, "Grok ")
    : "Grok 4.5";

  const liveActive =
    realtimeStatus === "connecting" ||
    realtimeStatus === "listening" ||
    realtimeStatus === "thinking" ||
    realtimeStatus === "speaking";

  const continuousArmed = liveActive || (voiceMode && isRecording);
  const waitingToResumeLive =
    liveVoice && !liveActive && !isRecording && !startingLiveRef.current;
  const displayInput = isRecording
    ? interimTranscript || input || "Listening…"
    : input;
  const canSend =
    (Boolean(input.trim()) || Boolean(pendingImage)) &&
    !isLoading &&
    !liveActive;

  return (
    <div className="relative flex h-full min-h-0 flex-col overflow-hidden text-fg">
      <SuiteBackdrop />
      <ScrollSuiteHeader tab="rvgrok" className="relative z-10" />


      <header className="relative z-10 flex items-center gap-2 border-b border-white/10 bg-black/25 px-3 py-2 sm:px-4">
        <button
          type="button"
          onClick={() => setHistoryOpen(true)}
          className="relative flex size-9 shrink-0 items-center justify-center rounded-full border border-white/20 bg-black/40 text-sky-100 transition hover:bg-white/10 sm:size-10"
          aria-label="Chat history"
        >
          <History className="size-5" />
          {sessions.length > 0 && (
            <span className="absolute -right-0.5 -top-0.5 flex size-4 items-center justify-center rounded-full bg-sky-500 text-[9px] font-bold text-white">
              {sessions.length > 9 ? "9+" : sessions.length}
            </span>
          )}
        </button>

        <div className="flex min-w-0 flex-1 items-center gap-2">
          <div className="min-w-0">
            <p className="truncate text-[10px] font-medium text-sky-100/90 sm:text-[11px]">
              {liveActive
                ? "Live Voice · hands-free"
                : isRecording
                  ? "Listening…"
                  : activeModel
                    ? modelLabel
                    : "AI RV Expert · live"}
            </p>
          </div>
        </div>

        <div className="flex shrink-0 items-center gap-1 sm:gap-1.5">
          <button
            type="button"
            onClick={toggleAgentMode}
            className={cn(
              "inline-flex items-center gap-1 rounded-full border px-2 py-1.5 text-[10px] font-bold transition sm:px-2.5 sm:text-[11px]",
              agentMode
                ? "border-sky-300/45 bg-sky-500/25 text-sky-50 shadow-[0_0_14px_rgba(80,160,255,0.35)]"
                : "border-white/20 bg-black/40 text-white",
            )}
          >
            <Sparkles className="size-3" />
            Agent
          </button>
          <button
            type="button"
            onClick={() => setVoicePanelOpen(true)}
            className={cn(
              "flex size-9 items-center justify-center rounded-full border transition",
              liveVoice || voiceMode
                ? "border-sky-300/45 bg-sky-500/20 text-sky-100"
                : "border-white/20 bg-black/40 text-white hover:bg-white/10",
            )}
            aria-label="Voice settings"
            title="Voice settings"
          >
            <Volume2 className="size-4" />
          </button>
          {messages.length > 0 && (
            <button
              type="button"
              onClick={startNewChat}
              className="flex size-9 items-center justify-center rounded-full border border-white/20 bg-black/40 text-white transition hover:bg-white/10"
              aria-label="New chat"
            >
              <Plus className="size-4" />
            </button>
          )}
          <button
            type="button"
            onClick={handleMicPress}
            className={cn(
              "flex size-9 items-center justify-center rounded-full border transition",
              liveActive
                ? "border-sky-300 bg-sky-500 text-white shadow-[0_0_16px_rgba(80,160,255,0.55)]"
                : waitingToResumeLive
                  ? "border-sky-300/45 bg-sky-500/20 text-sky-100 animate-pulse"
                  : "border-white/20 bg-black/40 text-white hover:bg-white/10",
            )}
            aria-label={
              liveActive ? "Stop live voice" : "Start live voice"
            }
            title={liveActive ? "Stop Live Voice" : "Start Live Voice"}
          >
            {liveActive ? (
              <Radio className="size-4 animate-pulse" />
            ) : (
              <Mic className="size-4" />
            )}
          </button>
        </div>
      </header>

      {sessionId && messages.length > 0 && (
        <div className="relative z-10 mx-3 mt-2 flex items-center gap-2 rounded-full border border-border bg-black/45 px-3 py-1.5 text-[11px] text-muted sm:mx-4">
          <span className="size-1.5 rounded-full bg-sky-500" />
          <span className="min-w-0 flex-1 truncate">
            {messages.find((m) => m.role === "user")?.content.slice(0, 50) ??
              "Current session"}
          </span>
          {agentMode && (
            <span className="inline-flex items-center gap-1 text-sky-100">
              <Sparkles className="size-2.5" />
              Agent
            </span>
          )}
        </div>
      )}

      <div
        ref={listRef}
        data-app-scroll
        className="rv-scroll relative z-10 flex-1 overflow-y-auto px-3 sm:px-4"
        style={{
          paddingBottom: kb.open ? 12 : undefined,
        }}
      >
        <PullResetHint
          show={pullHint}
          label="Release to reset Live Voice & chat · pull down"
        />
        {messages.length === 0 ? (
          <div className="mx-auto flex max-w-lg flex-col items-center px-4 pb-6 pt-6 text-center sm:pt-8">
            {agentMode && (
              <div className="mb-3 inline-flex items-center gap-1.5 rounded-full border border-sky-300/40 bg-sky-500/25 px-3.5 py-1.5 text-[12px] font-semibold text-sky-100 shadow-[0_0_18px_rgba(80,160,255,0.25)]">
                <Sparkles className="size-3.5" />
                Agent Mode Active — Multi-Step Research
              </div>
            )}

            <div className="flex flex-wrap items-center justify-center gap-2">
              <button
                type="button"
                onClick={() => setLiveVoiceArmed(true)}
                className="inline-flex items-center gap-1.5 rounded-full border border-sky-300/40 bg-sky-500 px-3.5 py-2 text-[12px] font-bold text-white shadow-[0_0_18px_rgba(80,160,255,0.35)] transition hover:bg-sky-400"
              >
                <Radio className="size-3.5" />
                Start Live Voice
              </button>
              <button
                type="button"
                onClick={() => cameraInputRef.current?.click()}
                className="inline-flex items-center gap-1.5 rounded-full border border-sky-300/40 bg-sky-500/15 px-3 py-2 text-[11px] font-semibold text-sky-100 transition hover:bg-sky-500/25"
              >
                <Camera className="size-3" />
                Photo
              </button>
              <button
                type="button"
                onClick={() => setVoicePanelOpen(true)}
                className="inline-flex items-center gap-1.5 rounded-full border border-border bg-black/40 px-3 py-2 text-[11px] font-semibold text-muted transition hover:border-sky-300/40 hover:text-sky-100"
              >
                <Volume2 className="size-3" />
                Settings
              </button>
            </div>

            {waitingToResumeLive && (
              <p className="mt-3 text-center text-[12px] text-sky-100">
                Live Voice is armed — tap mic to resume continuous listening
              </p>
            )}

            <p className="mt-8 max-w-sm text-center text-[11px] leading-relaxed text-dim">
              Tap the mic for Live Voice. Use the camera to analyze RV photos.
              Always verify data before transactions.
            </p>
          </div>
        ) : (
          <div className="mx-auto flex max-w-2xl flex-col gap-4 pb-4">
            {messages.map((m) => (
              <MessageBubble
                key={m.id}
                message={m}
                onSpeak={handleSpeak}
                speakingId={speakingId}
              />
            ))}
          </div>
        )}
      </div>

      <div className="relative z-10 border-t border-border/60 bg-gradient-to-t from-bg via-bg/95 to-bg/80 px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-2 sm:px-4">
        {(isLoading ||
          messages.some((m) => m.streaming) ||
          isRecording ||
          liveActive ||
          speakingId ||
          continuousArmed) && (
          <button
            type="button"
            onClick={handleStop}
            className="mb-2 flex w-full items-center gap-2 rounded-[var(--radius-md)] border border-sky-300/40 bg-sky-500/25 px-3 py-2.5 text-left transition hover:bg-sky-500/30"
          >
            <span className="flex size-7 items-center justify-center rounded-md bg-sky-500 text-white">
              <Square className="size-3.5 fill-current" />
            </span>
            <span className="flex-1 text-[13px] font-medium text-fg">
              {liveActive
                ? `Live continuous · ${realtimeDetail || realtimeStatus} — tap to end`
                : isRecording
                  ? voiceMode
                    ? "Auto-listening — tap to stop hands-free"
                    : "Recording — tap to stop & send"
                  : isLoading
                    ? "Processing — tap to cancel"
                    : "Speaking — tap to stop"}
            </span>
            <span className="text-[11px] font-bold tracking-wide text-sky-100">
              STOP
            </span>
          </button>
        )}

        {liveActive && (
          <div className="mx-auto mb-2 flex max-w-2xl items-center gap-2 rounded-full border border-sky-300/40 bg-sky-500/15 px-3 py-1.5">
            <span className="size-2 animate-pulse rounded-full bg-sky-500" />
            <Radio className="size-3 text-sky-100" />
            <span className="flex-1 text-[11px] font-medium text-sky-100">
              {realtimeDetail || `Live Grok Voice · ${realtimeStatus}`}
            </span>
            <span className="text-[10px] uppercase tracking-wide text-muted">
              {selectedVoice}
            </span>
          </div>
        )}

        {waitingToResumeLive && (
          <button
            type="button"
            onClick={() => void startLiveSession()}
            className="mx-auto mb-2 flex w-full max-w-2xl items-center gap-2 rounded-full border border-sky-300/40 bg-sky-500/15 px-3 py-2 text-left transition hover:bg-sky-500/25"
          >
            <Radio className="size-3.5 text-sky-100" />
            <span className="flex-1 text-[12px] font-semibold text-sky-100">
              Live Voice armed — tap mic to resume
            </span>
            <span className="text-[10px] font-bold text-muted">RESUME</span>
          </button>
        )}

        {voiceError && (
          <p className="mx-auto mb-2 max-w-2xl rounded-md border border-sky-300/40 bg-sky-500/15 px-3 py-1.5 text-center text-[11px] text-sky-100">
            {voiceError}
          </p>
        )}

        {pendingImage && (
          <div className="mx-auto mb-2 flex max-w-2xl items-center gap-2 rounded-[var(--radius-md)] border border-sky-300/35 bg-black/40 px-2 py-2">
            <img
              src={pendingImage}
              alt="Ready to send"
              className="size-14 shrink-0 rounded-md object-cover"
            />
            <div className="min-w-0 flex-1">
              <p className="text-[12px] font-semibold text-sky-100">
                Photo ready
              </p>
              <p className="text-[11px] text-white/65">
                Add a question or send to analyze
              </p>
            </div>
            <button
              type="button"
              onClick={() => setPendingImage(null)}
              className="flex size-8 items-center justify-center rounded-full border border-white/20 text-white/80 hover:bg-white/10"
              aria-label="Remove photo"
            >
              <X className="size-3.5" />
            </button>
          </div>
        )}

        <div
          className={cn(
            "mx-auto flex max-w-2xl items-end gap-1.5 rounded-[var(--radius-xl)] border bg-surface/90 px-2 py-2 shadow-[var(--shadow-panel)] focus-within:border-sky-300/40 sm:gap-2 sm:px-2.5",
            isRecording || liveActive
              ? "border-sky-300/40"
              : "border-border-strong",
          )}
        >
          <input
            ref={cameraInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0] ?? null;
              void onPickImage(f);
            }}
          />
          <button
            type="button"
            disabled={liveActive || imageBusy}
            onClick={() => cameraInputRef.current?.click()}
            className={cn(
              "mb-0.5 flex size-10 shrink-0 items-center justify-center rounded-full transition",
              pendingImage
                ? "bg-sky-500/25 text-sky-100"
                : "text-muted hover:bg-white/5 hover:text-fg",
              (liveActive || imageBusy) && "opacity-40",
            )}
            aria-label="Take or attach photo"
            title="Camera / photo"
          >
            {imageBusy ? (
              <Loader2 className="size-5 animate-spin" />
            ) : (
              <Camera className="size-5" />
            )}
          </button>
          <textarea
            value={displayInput}
            onChange={(e) => {
              if (!isRecording) setInput(e.target.value);
            }}
            onKeyDown={onKeyDown}
            rows={1}
            maxLength={2000}
            placeholder={
              isRecording
                ? "Listening… keep talking"
                : liveActive
                  ? "Live continuous — just speak"
                  : pendingImage
                    ? "Ask about this photo…"
                    : agentMode
                      ? "Ask Agent to research anything..."
                      : "Ask RV Grok"
            }
            className="max-h-28 min-h-[40px] flex-1 resize-none bg-transparent px-1.5 py-2 text-[14px] text-white outline-none placeholder:text-white/55 sm:px-2"
            readOnly={isRecording || liveActive}
          />
          <button
            type="button"
            onClick={handleMicPress}
            className={cn(
              "mb-0.5 flex size-10 shrink-0 items-center justify-center rounded-full transition",
              liveActive
                ? "bg-sky-500 text-white shadow-[0_0_14px_rgba(80,160,255,0.55)]"
                : "text-muted hover:bg-white/5 hover:text-fg",
            )}
            aria-label={liveActive ? "Stop live voice" : "Start live voice"}
            title={liveActive ? "Stop Live Voice" : "Start Live Voice"}
          >
            {liveActive ? (
              <Radio className="size-5 animate-pulse" />
            ) : (
              <Mic className="size-5" />
            )}
          </button>
          <button
            type="button"
            disabled={!canSend}
            onClick={() => void sendMessage()}
            className={cn(
              "mb-0.5 flex size-10 shrink-0 items-center justify-center rounded-full border transition",
              canSend
                ? "border-sky-300/40 bg-sky-500/15 text-sky-100 hover:bg-sky-500/25"
                : "border-border text-dim",
            )}
            aria-label="Send"
          >
            {isLoading ? (
              <Loader2 className="size-4 animate-spin text-sky-100" />
            ) : (
              <Send className="size-4" />
            )}
          </button>
        </div>

        {agentMode && !liveActive && (
          <div className="mx-auto mt-2 flex max-w-2xl items-center gap-2 rounded-full border border-sky-300/40 bg-sky-500/15 px-3 py-1.5">
            <Sparkles className="size-3 text-sky-100" />
            <span className="flex-1 text-[11px] font-medium text-sky-100/90">
              Agent Mode · Multi-step RV research with Grok 4.5
            </span>
            <button
              type="button"
              onClick={toggleAgentMode}
              className="text-[11px] font-bold text-muted transition hover:text-fg"
            >
              Off
            </button>
          </div>
        )}

        <p className="mx-auto mt-1.5 max-w-2xl text-center text-[10px] text-dim">
          {liveActive
            ? "Hands-free Live Voice · mic tap ends session"
            : waitingToResumeLive
              ? "Live Voice on · tap mic to listen continuously"
              : pendingImage
                ? "Photo attached · send or add a question"
                : "Mic = Live Voice · Camera = photo analysis"}
        </p>
      </div>

      <HistoryPanel
        open={historyOpen}
        sessions={sessions}
        onClose={() => setHistoryOpen(false)}
        onLoad={(s) => {
          setSessionId(s.id);
          setMessages(
            (s.messages ?? []).map((m) => ({
              ...m,
              timestamp:
                m.timestamp instanceof Date
                  ? m.timestamp
                  : new Date(m.timestamp),
            })),
          );
        }}
        onDelete={(id) => {
          const next = deleteSession(sessions, id);
          setSessions(next);
          if (sessionId === id) startNewChat();
        }}
        onNewChat={startNewChat}
      />

      <VoicePanel
        open={voicePanelOpen}
        onClose={() => {
          setVoicePanelOpen(false);
          stopBrowserTts();
          setPreviewingId(null);
        }}
        selectedId={selectedVoice}
        onSelect={persistVoice}
        voiceMode={voiceMode}
        onVoiceModeChange={setVoiceModeArmed}
        liveVoice={liveVoice}
        onLiveVoiceChange={setLiveVoiceArmed}
        playbackSpeed={playbackSpeed}
        onSpeedChange={persistSpeed}
        onPreview={handlePreviewVoice}
        previewingId={previewingId}
      />
    </div>
  );
}
