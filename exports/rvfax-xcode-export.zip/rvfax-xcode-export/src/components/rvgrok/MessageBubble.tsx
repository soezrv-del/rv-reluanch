import { Loader2, Square, Volume2 } from "lucide-react";
import type { Message } from "@/lib/rvgrok/types";
import { formatTime, cn } from "@/lib/utils";
import { AgentBadge, AgentStepsCard } from "./AgentStepsCard";

function renderContent(text: string) {
  const lines = text.split("\n");
  return lines.map((line, i) => {
    if (line.startsWith("|") && line.includes("|")) {
      return (
        <div
          key={i}
          className="my-1 overflow-x-auto font-mono text-[11px] text-white"
        >
          {line}
        </div>
      );
    }
    const parts = line.split(/(\*\*[^*]+\*\*)/g);
    return (
      <p key={i} className={cn("min-h-[0.4em] leading-relaxed", i > 0 && "mt-1")}>
        {parts.map((part, j) => {
          if (part.startsWith("**") && part.endsWith("**")) {
            return (
              <strong key={j} className="font-semibold text-white">
                {part.slice(2, -2)}
              </strong>
            );
          }
          if (part.startsWith("_") && part.endsWith("_") && part.length > 2) {
            return (
              <em key={j} className="text-white not-italic">
                {part.slice(1, -1)}
              </em>
            );
          }
          return <span key={j}>{part}</span>;
        })}
      </p>
    );
  });
}

export function MessageBubble({
  message,
  onSpeak,
  speakingId,
}: {
  message: Message;
  onSpeak?: (id: string, text: string) => void;
  speakingId?: string | null;
}) {
  const isUser = message.role === "user";
  const hasAgentSteps =
    !isUser && message.isAgentMode && (message.agentSteps?.length ?? 0) > 0;
  const isSpeaking = speakingId === message.id;

  return (
    <div
      className={cn(
        "flex w-full gap-2.5",
        isUser ? "justify-end" : "justify-start",
      )}
    >
      {!isUser && (
        <div className="relative mt-1 size-9 shrink-0 overflow-hidden rounded-full border border-ruby-border bg-black shadow-[0_0_16px_rgba(212,37,53,0.35)]">
          <img
            src="/assets/brand/icon-rvgrok.png"
            alt=""
            className="size-full object-contain"
          />
        </div>
      )}

      <div
        className={cn(
          "max-w-[min(100%,28rem)] rounded-[var(--radius-lg)] px-3.5 py-3 text-sm",
          isUser
            ? "rounded-br-sm bg-ruby text-white shadow-[0_4px_20px_rgba(212,37,53,0.35)]"
            : "rounded-bl-sm border border-border-strong bg-surface/90 text-white shadow-[var(--shadow-panel)]",
        )}
      >
        {hasAgentSteps ? (
          <div className="mb-2">
            <AgentBadge />
            <AgentStepsCard steps={message.agentSteps!} />
          </div>
        ) : null}

        {message.imageDataUrl ? (
          <div className="mb-2 overflow-hidden rounded-lg border border-white/20">
            <img
              src={message.imageDataUrl}
              alt="Attached photo"
              className="max-h-52 w-full object-cover"
            />
          </div>
        ) : null}

        {message.streaming && !message.content ? (
          <p className="flex items-center gap-2 text-white/80">
            <Loader2 className="size-3.5 animate-spin" />
            Thinking…
          </p>
        ) : (
          renderContent(message.content || "")
        )}

        <div className="mt-2 flex items-center justify-between gap-2">
          <span className="text-[10px] opacity-60">
            {formatTime(
              message.timestamp instanceof Date
                ? message.timestamp
                : new Date(message.timestamp),
            )}
          </span>
          {!isUser && message.content && onSpeak ? (
            <button
              type="button"
              onClick={() => onSpeak(message.id, message.content)}
              className="inline-flex items-center gap-1 text-[10px] font-semibold opacity-80 hover:opacity-100"
            >
              {isSpeaking ? (
                <Square className="size-3" />
              ) : (
                <Volume2 className="size-3" />
              )}
              {isSpeaking ? "Stop" : "Speak"}
            </button>
          ) : null}
        </div>
      </div>
    </div>
  );
}
