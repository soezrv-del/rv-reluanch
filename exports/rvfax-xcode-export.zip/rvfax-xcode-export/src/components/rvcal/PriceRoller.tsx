import { useCallback, useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";
import { hapticSnap, preloadHaptics } from "@/lib/haptics";

const STEP_SLOW = 1_000;
const STEP_MED = 5_000;
const STEP_FAST = 10_000;

/** px/ms thresholds for three-tier stepping */
const V_MED = 0.32;
const V_FAST = 0.7;

/** Pixels of drag per step */
const PX_PER_STEP = 20;
const MIN = 0;
const MAX = 5_000_000;

function clampMoney(n: number) {
  if (!Number.isFinite(n)) return 0;
  return Math.min(MAX, Math.max(MIN, Math.round(n)));
}

function snapToStep(n: number, step: number) {
  return clampMoney(Math.round(n / step) * step);
}

function formatUsd(n: number) {
  return n.toLocaleString("en-US");
}

function stepFromVelocity(v: number): number {
  if (v >= V_FAST) return STEP_FAST;
  if (v >= V_MED) return STEP_MED;
  return STEP_SLOW;
}

function stepLabel(step: number): string {
  if (step >= STEP_FAST) return "Fast · $10,000";
  if (step >= STEP_MED) return "Medium · $5,000";
  return "Slow · $1,000";
}

type Props = {
  value: number;
  onChange: (next: number) => void;
  className?: string;
  "aria-label"?: string;
  label?: string;
};

/**
 * Three-tier velocity money roller (captures gesture so parent card won't scroll).
 * Slow → $1k · Medium → $5k · Fast → $10k
 */
export function PriceRoller({
  value,
  onChange,
  className,
  "aria-label": ariaLabel = "Price roller",
  label = "Swipe to set amount",
}: Props) {
  const trackRef = useRef<HTMLDivElement | null>(null);
  const valueRef = useRef(value);
  const dragging = useRef(false);
  const lastY = useRef(0);
  const lastT = useRef(0);
  const accum = useRef(0);
  const lastHaptic = useRef(0);
  const [live, setLive] = useState(value);
  const [stepHint, setStepHint] = useState(STEP_SLOW);
  const [active, setActive] = useState(false);

  useEffect(() => {
    preloadHaptics();
  }, []);

  useEffect(() => {
    if (dragging.current) return;
    valueRef.current = value;
    setLive(value);
  }, [value]);

  const tickHaptic = useCallback(() => {
    const now = Date.now();
    if (now - lastHaptic.current < 30) return;
    lastHaptic.current = now;
    void hapticSnap();
  }, []);

  const commit = useCallback(
    (next: number, step: number) => {
      const snapped = snapToStep(next, step);
      if (snapped === valueRef.current) return;
      valueRef.current = snapped;
      setLive(snapped);
      onChange(snapped);
      tickHaptic();
    },
    [onChange, tickHaptic],
  );

  /** Lock parent scroll while finger is on the roller */
  const lockParentScroll = (lock: boolean) => {
    const el = trackRef.current;
    if (!el) return;
    // Walk up and freeze nearest scroll containers (sliding card / page)
    let node: HTMLElement | null = el.parentElement;
    while (node) {
      const style = window.getComputedStyle(node);
      const oy = style.overflowY;
      if (
        oy === "auto" ||
        oy === "scroll" ||
        oy === "overlay" ||
        node.hasAttribute("data-app-scroll")
      ) {
        if (lock) {
          node.dataset.priceRollerLock = "1";
          (node as HTMLElement).style.overflowY = "hidden";
          (node as HTMLElement).style.touchAction = "none";
        } else if (node.dataset.priceRollerLock === "1") {
          delete node.dataset.priceRollerLock;
          (node as HTMLElement).style.overflowY = "";
          (node as HTMLElement).style.touchAction = "";
        }
      }
      node = node.parentElement;
    }
    // Also flag body for overscroll
    if (lock) {
      document.documentElement.style.overscrollBehavior = "none";
    } else {
      document.documentElement.style.overscrollBehavior = "";
    }
  };

  useEffect(() => {
    return () => lockParentScroll(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onPointerDown = (e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dragging.current = true;
    setActive(true);
    lastY.current = e.clientY;
    lastT.current = performance.now();
    accum.current = 0;
    lockParentScroll(true);
    try {
      trackRef.current?.setPointerCapture(e.pointerId);
    } catch {
      /* */
    }
  };

  const onPointerMove = (e: React.PointerEvent) => {
    if (!dragging.current) return;
    e.preventDefault();
    e.stopPropagation();
    const now = performance.now();
    const dy = e.clientY - lastY.current;
    const dt = Math.max(6, now - lastT.current);
    const velocity = Math.abs(dy) / dt;
    const step = stepFromVelocity(velocity);
    setStepHint(step);

    // iOS UIPicker: finger moves up → value increases; finger moves down → decreases.
    // dy = clientY delta (up is negative) → accumulate opposite sign.
    accum.current -= dy;
    lastY.current = e.clientY;
    lastT.current = now;

    // Faster velocity slightly lower pixel cost so flings feel snappy
    const pxNeeded =
      step === STEP_FAST ? PX_PER_STEP * 0.75 : step === STEP_MED ? PX_PER_STEP * 0.9 : PX_PER_STEP;

    while (Math.abs(accum.current) >= pxNeeded) {
      const dir = accum.current > 0 ? 1 : -1;
      accum.current -= dir * pxNeeded;
      commit(valueRef.current + dir * step, step);
    }
  };

  const endDrag = (e: React.PointerEvent) => {
    if (!dragging.current) return;
    e.preventDefault();
    e.stopPropagation();
    dragging.current = false;
    setActive(false);
    accum.current = 0;
    lockParentScroll(false);
    try {
      trackRef.current?.releasePointerCapture(e.pointerId);
    } catch {
      /* */
    }
    // Clean snap to $1k grid
    const cleaned = snapToStep(valueRef.current, STEP_SLOW);
    if (cleaned !== valueRef.current) {
      valueRef.current = cleaned;
      setLive(cleaned);
      onChange(cleaned);
    }
  };

  const nudge = (dir: 1 | -1, step: number) => {
    commit(valueRef.current + dir * step, step);
  };

  const display = live > 0 ? formatUsd(live) : "0,000";
  // iOS ascending strip: smaller values above the selection, larger below.
  // Swipe up brings the next-higher value from below into the center.
  const neighbors = [
    snapToStep(Math.max(0, live - stepHint * 2), stepHint),
    snapToStep(Math.max(0, live - stepHint), stepHint),
    live,
    snapToStep(live + stepHint, stepHint),
    snapToStep(live + stepHint * 2, stepHint),
  ];

  return (
    <div
      className={cn("select-none", className)}
      data-no-swipe
      onTouchMove={(e) => {
        // Stop page/card scroll while finger is on the roller surface
        if (dragging.current) e.preventDefault();
        e.stopPropagation();
      }}
      onWheel={(e) => {
        e.preventDefault();
        e.stopPropagation();
        const step =
          Math.abs(e.deltaY) > 40
            ? STEP_FAST
            : Math.abs(e.deltaY) > 18
              ? STEP_MED
              : STEP_SLOW;
        setStepHint(step);
        nudge(e.deltaY < 0 ? 1 : -1, step);
      }}
    >
      <div className="mb-1.5 flex items-center justify-between gap-2">
        <p className="text-[10px] font-bold tracking-[0.12em] text-white/70">
          {label}
        </p>
        <p className="text-[10px] font-semibold tabular-nums text-sky-200/90">
          {stepLabel(stepHint)}
        </p>
      </div>

      <div
        ref={trackRef}
        role="slider"
        tabIndex={0}
        aria-label={ariaLabel}
        aria-valuemin={MIN}
        aria-valuemax={MAX}
        aria-valuenow={live}
        aria-valuetext={`$${display}`}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={endDrag}
        onPointerCancel={endDrag}
        onTouchStart={(e) => e.stopPropagation()}
        onTouchMove={(e) => {
          e.stopPropagation();
          if (dragging.current) e.preventDefault();
        }}
        onKeyDown={(e) => {
          if (e.key === "ArrowUp" || e.key === "ArrowRight") {
            e.preventDefault();
            nudge(1, e.shiftKey ? STEP_FAST : e.altKey ? STEP_MED : STEP_SLOW);
          } else if (e.key === "ArrowDown" || e.key === "ArrowLeft") {
            e.preventDefault();
            nudge(-1, e.shiftKey ? STEP_FAST : e.altKey ? STEP_MED : STEP_SLOW);
          } else if (e.key === "PageUp") {
            e.preventDefault();
            nudge(1, STEP_FAST);
          } else if (e.key === "PageDown") {
            e.preventDefault();
            nudge(-1, STEP_FAST);
          }
        }}
        className={cn(
          "relative touch-none overflow-hidden rounded-[1.1rem] border border-white/18 bg-black/35 py-1 shadow-[inset_0_1px_0_rgba(255,255,255,0.12)]",
          "cursor-ns-resize outline-none focus-visible:ring-2 focus-visible:ring-sky-400/50",
          active && "border-sky-300/40 bg-black/45",
        )}
        style={{ height: 148, touchAction: "none", overscrollBehavior: "contain" }}
      >
        <div
          aria-hidden
          className="pointer-events-none absolute inset-x-2 top-1/2 z-[1] h-10 -translate-y-1/2 rounded-xl border border-sky-300/35 bg-sky-400/10 shadow-[0_0_24px_rgba(80,160,255,0.18)]"
        />
        <div
          aria-hidden
          className="pointer-events-none absolute inset-x-0 top-0 z-[2] h-8 bg-gradient-to-b from-black/70 to-transparent"
        />
        <div
          aria-hidden
          className="pointer-events-none absolute inset-x-0 bottom-0 z-[2] h-8 bg-gradient-to-t from-black/70 to-transparent"
        />

        <div className="relative z-0 flex h-full flex-col items-center justify-center gap-0.5">
          {neighbors.map((n, i) => {
            const isCenter = i === 2;
            return (
              <div
                key={`${i}-${n}`}
                className={cn(
                  "flex h-7 w-full items-center justify-center tabular-nums transition-all duration-75",
                  isCenter
                    ? "text-[20px] font-black text-white"
                    : i === 1 || i === 3
                      ? "text-[13px] font-semibold text-white/45"
                      : "text-[11px] font-medium text-white/25",
                )}
              >
                <span className={cn(isCenter && "text-gold")}>$</span>
                {n > 0 ? formatUsd(n) : "0,000"}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
