RvFOX / RvFACTS — Grok handoff (2026-08-28)

START HERE: HANDOFF.md

Live catalog the app uses: src/lib/rv/rvData.ts
(also copied under catalog/rvData.ts)

Unzip into a Grok Build workspace. npm install if needed.
Do not copy node_modules. Do not invent horsepower.
