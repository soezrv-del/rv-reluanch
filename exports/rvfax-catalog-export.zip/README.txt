RvFACTS Catalog Export
======================
Exported: 2026-08-09T04:24:18Z
Source: src/lib/rv/rvData.ts
Makes: 50
Models: 363
Powertrain year-band rows: 400

Files
-----
- rvfax-catalog-models.json     Full structured catalog (models + powertrainByYear + era fields)
- rvfax-catalog-models.csv      Flat model spreadsheet
- rvfax-catalog-powertrain-by-year.csv  Long-form engine/HP by year band
- rvfax-catalog-models.txt      Human-readable summary
- README.txt                   This file

Key fields
----------
engine / horsepower           Modern / default catalog values
engine2000_2005 etc.          Era-resolved powertrain when year bands exist
powertrainByYear              Array of {from,to,engine,horsepower,chassis}

Notes
-----
- Towables may have null engine/horsepower (no powertrain).
- Era fields are present for motorized models with coverage in that window.
- Always verify critical OEM specs against current brochures for transactions.
