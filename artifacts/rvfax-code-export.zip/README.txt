RVFAX / RvFOX — Code Export
Generated: 2026-08-19

CONTENTS
--------
catalog/
  rv_catalog.json     Current catalog snapshot (JSON)
  rv_catalog.csv      Same data as CSV

code/                 Phase 3 lazy-catalog drop-in (recommended)
  constants/rvData.ts       Thin cold-start seed (~5KB)
  constants/rvDataFull.ts   Full model data (lazy-loaded)
  constants/rvReviews.ts    Reviews split off boot path
  services/catalogSync.ts   Daily remote merge client
  patches/index.tsx         Access-gate timeout patch
  INTEGRATION.md            Install steps
  FACTS-WIRING.md           Facts wiring notes
  PHASE3-NOTES.md
  README.md

patches/              Earlier load-path + UI patches
  phase2/             Lean rich catalog + reviews split
  phase3/             Lazy catalog install notes
  PHASE1-ACCESS-TIMEOUT.md
  index.tsx

recovery/
  rvData.WORKING-july28.ts  Known-good lean seed if UI blacks out

INSTALL ORDER
-------------
1. Read code/INTEGRATION.md and code/FACTS-WIRING.md
2. Drop Phase 3 constants + catalogSync into the July-28 codebase
3. Apply access-gate timeout patch if not already present
4. Keep recovery seed available if a full merge causes black screens

NOTES
-----
- Prefer Phase 3 lazy load over shipping full catalog on boot
- Grow catalog incrementally; do not replace working seed with a 390KB+ synchronous module
- Daily sync: Edge Function upserts rv_catalog; client merges on RvFacts mount
