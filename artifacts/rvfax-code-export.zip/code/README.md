# RV Facts — Active Daily Catalog Update (v4 + Phase 3)

**Target codebase:** July-28 RVFAX (`code 8:28.zip`)  
**Purpose:** Once a day, scan for missing RV models from **2010 → present**, discover new models for the **current + prior year**, pull the latest data, and sync it across the app without an App Store release.

## How the daily job works

1. **New-model scan** — Grok is asked for every distinct model line in active production for the current year and the prior year (priority manufacturers).
2. **Gap fill (2010–present)** — For each priority make, Grok sees the models already in `rv_catalog` and returns important missing production lines (capped ~12 per make per run). This steadily closes historical gaps.
3. **Upsert** into `public.rv_catalog` (unique on `make, model`).
4. On the device, `refreshCatalogFromServer()` (called when RvFacts opens) merges remote rows into the live in-memory catalog so users see new models immediately.

## Cold-start safety (Phase 3)

- `constants/rvData.ts` is a **thin facade** (~5 KB). Full model data lives in `rvDataFull.ts` and is loaded **only when RvFacts opens**.
- Review pools stay in `rvReviews.ts` (off the boot path).
- Phase 1 access-gate timeout (2.5 s fail-open) is included so the Facts tab never hangs black while waiting on Supabase.

Static seed: **50 makes / ~368 models**, `YEARS` = 2000–2027.  
Pins include Thor Vegas/Axis, Jayco Seneca (Cummins/Freightliner), Roadtrek, Pleasure-Way, Leisure Travel Vans, etc.

---

## Install order

### 1. Database (one-time)

Run the migration on the OnSpace / Supabase project:

```text
supabase/migrations/20260809_rv_catalog.sql
```

Creates `public.rv_catalog`, `public.catalog_sync_logs`, and the helper RPC.

### 2. Edge Function + secrets

```text
supabase/functions/catalog-sync/   →  your project’s supabase/functions/catalog-sync/
```

(Your codebase already has `supabase/functions/_shared/cors.ts` — the function imports it.)

Required secrets:

| Secret                      | Purpose                      |
|-----------------------------|------------------------------|
| `SUPABASE_URL`              | Project URL                  |
| `SUPABASE_SERVICE_ROLE_KEY` | Write access to `rv_catalog` |
| `XAI_API_KEY`               | Grok for model discovery     |

```bash
supabase functions deploy catalog-sync
```

### 3. Daily schedule (recommended 06:00 UTC)

```sql
SELECT cron.schedule(
  'rvfax-catalog-daily',
  '0 6 * * *',
  $$
  SELECT net.http_post(
    url := 'https://rtlqkunyokumxrdwrtlq.backend.onspace.ai/functions/v1/catalog-sync',
    headers := '{"Authorization": "Bearer <SERVICE_ROLE_KEY>", "Content-Type": "application/json"}'::jsonb,
    body := '{}'::jsonb
  );
  $$
);
```

You can also POST to the function manually any time with the service-role key.

### 4. App files (copy into the July-28 tree)

```text
constants/rvData.ts        ←  thin facade
constants/rvDataFull.ts    ←  full 50/368 models (lazy)
constants/rvReviews.ts     ←  review pools (off boot path)
services/catalogSync.ts    ←  throttled merge (awaits local load)
```

Optional but recommended (prevents black-screen hang on access check):

```text
app/(tabs)/index.tsx       ←  patches/index.tsx
```

### 5. Wire RvFacts (required)

Follow **FACTS-WIRING.md** exactly:

- Import `ensureCatalogLoaded`, `isCatalogLoaded`, `refreshCatalogFromServer`
- `catalogReady` state
- `useEffect` on Facts mount that calls `ensureCatalogLoaded()` then `refreshCatalogFromServer()`
- Gate the search UI with a short “Loading RV catalog…” while `!catalogReady`

Do **not** call `ensureCatalogLoaded()` from the root layout or other tabs.

### 6. Clean reload

```bash
npx expo start -c
```

---

## Verification

**Server**

```sql
SELECT make, model, type, year_start, source, updated_at
FROM rv_catalog
ORDER BY updated_at DESC
LIMIT 20;

SELECT * FROM catalog_sync_logs ORDER BY ran_at DESC LIMIT 3;
```

**Client console**

```
[catalogSync] Merged remote catalog — added N, updated M
```

**UI**

- Cold open other tabs → instant (no full catalog parse)
- Open **RvFacts** → brief “Loading RV catalog…” then pickers fill
- Search **2025/2026 → Jayco → Seneca** → diesel Cummins / Freightliner
- Search **Thor → Vegas / Axis**
- New models discovered overnight appear after the next refresh (or app restart)

---

## Files in this package

```
README.md
INTEGRATION.md          (original v4 notes)
FACTS-WIRING.md         (exact Facts screen hooks)
PHASE3-NOTES.md
constants/
  rvData.ts             # ~5 KB facade
  rvDataFull.ts         # full seed (dynamic import)
  rvReviews.ts
services/
  catalogSync.ts
patches/
  index.tsx             # Phase 1 2.5 s access timeout
supabase/
  functions/catalog-sync/index.ts
  migrations/20260809_rv_catalog.sql
```

## Design notes

- The Edge Function is intentionally conservative (priority makes, ~12 gap models per make) so a daily run stays fast and inexpensive while still closing the 2010–present catalog over weeks.
- New **makes** discovered by the job are merged into the live `RV_DATA` object. A soft restart surfaces brand-new manufacturers in the make picker.
- Cal / Tow / Trips / Grok were left untouched for stability.
- Never re-introduce a single 390 KB+ `rvData.ts` that glues reviews + catalog together — that caused the earlier black-screen regression.
